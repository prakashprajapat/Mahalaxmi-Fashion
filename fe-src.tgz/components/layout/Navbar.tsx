'use client';
import Link from 'next/link';
import Image from 'next/image';
import { useState, useEffect, useRef } from 'react';
import type { FormEvent } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { getCart, cartCount, finalUnitPrice } from '@/lib/cart';
import { getCustomer, setCustomer as saveCustomer, setToken, logout } from '@/lib/auth';
import { customersApi, settingsApi, productsApi } from '@/lib/api';
import { trackEvent } from '@/lib/analytics';
import { productSlug } from '@/lib/productSlug';
import { productImageSrc } from '@/lib/productImages';
import { getWishlist } from '@/lib/wishlist';
import type { Product } from '@/types';

// Cache the catalogue once (module-level) so search suggestions don't refetch on every keystroke.
let _searchCache: Product[] | null = null;
// Shared in-flight fetch so quick typing before the first response doesn't fire the
// 200-item catalogue request several times over (and race each other's results).
let _searchCachePromise: Promise<Product[]> | null = null;

// Module-level settings cache — survives re-renders and SPA navigation
let _settingsCache: Record<string, string> | null = null;
let _settingsExpiry = 0;

export default function Navbar() {
  const router = useRouter();
  const pathname = usePathname();
  const [count, setCount] = useState(0);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [search, setSearch] = useState('');
  const [suggestions, setSuggestions] = useState<Product[]>([]);
  const [showSuggest, setShowSuggest] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [catOpen, setCatOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const open = () => setMenuOpen(true);
    const openCat = () => setCatOpen(true);
    const openAcc = () => setAccountOpen(true);
    // Desktop: once the header search scrolls out of view, reveal the search in the sticky nav.
    const onScroll = () => setScrolled(window.scrollY > 140);
    onScroll();
    window.addEventListener('mfh-open-menu', open);
    window.addEventListener('mfh-open-categories', openCat);
    window.addEventListener('mfh-open-account', openAcc);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      window.removeEventListener('mfh-open-menu', open);
      window.removeEventListener('mfh-open-categories', openCat);
      window.removeEventListener('mfh-open-account', openAcc);
      window.removeEventListener('scroll', onScroll);
    };
  }, []);
  const [loginOpen, setLoginOpen] = useState(false);
  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [loginError, setLoginError] = useState('');
  const [loginLoading, setLoginLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  // Mobile/Email OTP login
  const [loginMode, setLoginMode] = useState<'password' | 'otp'>('password');
  const [otpContact, setOtpContact] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpLoading, setOtpLoading] = useState(false);
  const [otpMsg, setOtpMsg] = useState('');
  const [cartBounce, setCartBounce] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhoto, setCustomerPhoto] = useState('');
  const [customerFull, setCustomerFull] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [wishCount, setWishCount] = useState(0);
  const [acctMenu, setAcctMenu] = useState(false);
  const acctRef = useRef<HTMLDivElement | null>(null);
  const [showWaLogin, setShowWaLogin] = useState(true);
  const [enableGoogleLogin, setEnableGoogleLogin] = useState(false);
  const [googleClientId, setGoogleClientId] = useState('');
  const [enableFacebookLogin, setEnableFacebookLogin] = useState(false);
  const [facebookAppId, setFacebookAppId] = useState('');
  const prevCountRef = useRef(0);

  useEffect(() => {
    const update = () => {
      const newCount = cartCount(getCart());
      // Bounce animation when item is added
      if (newCount > prevCountRef.current) {
        setCartBounce(true);
        setTimeout(() => setCartBounce(false), 650);
      }
      prevCountRef.current = newCount;
      setCount(newCount);
      const c = getCustomer();
      setIsLoggedIn(!!c);
      setCustomerName(c ? c.firstName : '');
      setCustomerFull(c ? [c.firstName, c.lastName].filter(Boolean).join(' ').trim() : '');
      setCustomerPhone(c && c.phone ? c.phone : '');
      setCustomerPhoto(c && (c as any).photoUrl ? (c as any).photoUrl : '');
      try { setWishCount(getWishlist().length); } catch { setWishCount(0); }
    };
    update();
    window.addEventListener('cart-updated', update);
    window.addEventListener('auth-changed', update);
    window.addEventListener('wishlist-updated', update);
    return () => {
      window.removeEventListener('cart-updated', update);
      window.removeEventListener('auth-changed', update);
      window.removeEventListener('wishlist-updated', update);
    };
  }, []);

  // Desktop account dropdown: close on outside click or Esc.
  useEffect(() => {
    if (!acctMenu) return;
    const onDown = (e: MouseEvent) => {
      if (acctRef.current && !acctRef.current.contains(e.target as Node)) setAcctMenu(false);
    };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setAcctMenu(false); };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [acctMenu]);

  // Close menu on route change (depend on pathname so it also fires on back/forward nav)
  useEffect(() => { setMenuOpen(false); setAcctMenu(false); }, [pathname]);

  // Load login settings — cached for 5 min to avoid repeated API calls
  useEffect(() => {
    const applySettings = (s: Record<string, string>) => {
      setShowWaLogin(s.showWhatsappLogin !== 'false');
      setEnableGoogleLogin(s.enableGoogleLogin === 'true');
      setGoogleClientId(s.googleClientId ?? '');
      setEnableFacebookLogin(s.enableFacebookLogin === 'true');
      setFacebookAppId(s.facebookAppId ?? '');
    };

    // Serve from cache if still fresh
    if (_settingsCache && Date.now() < _settingsExpiry) {
      applySettings(_settingsCache);
      return;
    }

    settingsApi.getAll()
      .then(r => {
        const s = r.settings ?? {};
        _settingsCache = s;
        _settingsExpiry = Date.now() + 5 * 60 * 1000; // 5-min TTL
        applySettings(s);
      })
      .catch(() => {});
  }, []);

  // Clear every login-form field so one user's phone/OTP never lingers for the next
  const resetLoginForm = () => {
    setLoginForm({ email: '', password: '' });
    setLoginError('');
    setShowPassword(false);
    setLoginMode('password');
    setOtpContact('');
    setOtpCode('');
    setOtpSent(false);
    setOtpMsg('');
    setOtpLoading(false);
  };

  const openLogin = () => {
    setMenuOpen(false);
    resetLoginForm();
    setLoginOpen(true);
  };

  const closeLogin = () => {
    setLoginOpen(false);
    resetLoginForm();
  };

  // Instant search suggestions: filter the (cached) catalogue by name / category / SKU.
  const runSuggest = async (q: string) => {
    const query = q.trim().toLowerCase();
    if (query.length < 2) { setSuggestions([]); return; }
    if (!_searchCache) {
      _searchCachePromise ??= productsApi.getAll({ pageSize: 200 }).then(r => r.products ?? []).catch(() => []);
      _searchCache = await _searchCachePromise;
    }
    const matches = _searchCache.filter(p =>
      (p.name ?? '').toLowerCase().includes(query) ||
      (p.category ?? '').toLowerCase().includes(query) ||
      ((p as any).sku ?? '').toLowerCase().includes(query)
    ).slice(0, 6);
    setSuggestions(matches);
  };

  const handleLogin = async (e: FormEvent) => {
    e.preventDefault();
    setLoginLoading(true);
    setLoginError('');
    try {
      const res = await customersApi.login({ email: loginForm.email, password: loginForm.password });
      setToken(res.token);
      saveCustomer(res.customer);
      trackEvent('login', { method: 'password' });   // GA4
      setIsLoggedIn(true);
      setLoginOpen(false);
      resetLoginForm();
      window.dispatchEvent(new Event('auth-changed'));
    } catch (err) {
      setLoginError((err as Error).message || 'Login failed. Please check your credentials.');
    } finally {
      setLoginLoading(false);
    }
  };

  const handleSendOtp = async () => {
    const contact = otpContact.trim();
    if (!contact) { setOtpMsg('Enter your mobile number or email.'); return; }
    setOtpLoading(true); setOtpMsg('');
    try {
      const isEmail = contact.includes('@');
      if (isEmail) await customersApi.sendEmailOtp(contact);
      else await customersApi.sendOtp(contact);
      setOtpSent(true);
      setOtpMsg(`OTP sent to your ${isEmail ? 'email' : 'mobile'}.`);
    } catch (err) {
      setOtpMsg((err as Error).message || 'Could not send OTP. Please try again.');
    } finally {
      setOtpLoading(false);
    }
  };

  const handleVerifyOtp = async () => {
    if (otpCode.trim().length < 4) { setOtpMsg('Enter the OTP you received.'); return; }
    setOtpLoading(true); setOtpMsg('');
    try {
      const res = await customersApi.verifyOtp(otpContact.trim(), otpCode.trim());
      if (res.newUser || !res.token || !res.customer) {
        setOtpMsg('No account found for this number/email. Please create a new account.');
        return;
      }
      setToken(res.token);
      saveCustomer(res.customer);
      trackEvent('login', { method: 'otp' });   // GA4
      setIsLoggedIn(true);
      setLoginOpen(false);
      resetLoginForm();
      window.dispatchEvent(new Event('auth-changed'));
    } catch (err) {
      setOtpMsg((err as Error).message || 'Invalid OTP. Please try again.');
    } finally {
      setOtpLoading(false);
    }
  };

  // Reset OTP flow whenever switching modes or closing the modal
  const switchToOtp = () => { setLoginMode('otp'); setOtpSent(false); setOtpCode(''); setOtpMsg(''); };
  const switchToPassword = () => { setLoginMode('password'); setOtpMsg(''); };

  return (
    <>
      {/* Topbar */}
      <div className="topbar">
        <p>Welcome to Mahalaxmi Fashion Hub!</p>
        <p>Order / Return / Exchange / Customization / Bulk Orders:{' '}
          <a href="https://wa.me/919429429880" target="_blank" rel="noopener noreferrer">WhatsApp +91 9429429880</a>
        </p>
      </div>

      {/* Sticky mobile header wrapper: greeting + logo/search stay fixed on scroll */}
      <div className="m-head">
      {/* Mobile greeting bar (reference-style) — mobile only via CSS */}
      <div className="mobile-greet">
        <div className="mg-hello">
          <span className="mg-avatar" aria-hidden="true">
            {isLoggedIn && customerPhoto
              ? <img src={customerPhoto} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: '50%' }} />
              : (isLoggedIn && customerName ? customerName.charAt(0).toUpperCase() : '🙏')}
          </span>
          <span className="mg-text">
            {isLoggedIn && customerName
              ? (<><small>Hello,</small><b>{customerName}</b></>)
              : (<><b>Hello</b><small>let&apos;s shop!</small></>)}
          </span>
        </div>
        <div className="mg-actions">
          <Link href="/wishlist" className="mg-icon" aria-label="Wishlist">
            <svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
          </Link>
          <Link href="/cart" className="mg-icon" aria-label="Cart" style={{ position: 'relative' }}>
            <svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zm10 0c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2zM7.16 14h9.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49A1 1 0 0 0 21.16 5H5.21l-.94-2H1v2h2l3.6 7.59-1.35 2.44C4.52 15.37 5.48 17 7 17h12v-2H7.16c-.14 0-.25-.11-.25-.25l.03-.12L7.16 14z"/></svg>
            {count > 0 && <span className="mg-badge">{count}</span>}
          </Link>
        </div>
      </div>

      {/* Header — policy-nav strip removed (declutter); policy links live in the footer,
          and "Become a Seller" now sits in the offer strip above. */}
      <header className="site-header">

        <div className="brand-row">
          <Link href="/" className="brand" aria-label="Mahalaxmi Fashion Hub home">
            <span className="brand-mark">
              <Image src="/logo.webp" alt="Mahalaxmi Fashion Hub logo"
                width={547} height={300} priority sizes="(max-width: 900px) 110px, 160px" />
            </span>
          </Link>

          {/* Desktop-only inline nav — puts logo + nav + search + cart + login on one row */}
          <nav className="hdr-nav" aria-label="Shop by department">
            {[
              { href: '/', label: 'Home' },
              { href: '/best-sellers', label: 'Best Sellers' },
              { href: '/women', label: 'Women' },
              { href: '/men', label: 'Men' },
              { href: '/kids', label: 'Kids' },
              { href: '/beauty', label: 'Beauty' },
              { href: '/fabrics', label: 'Fabrics' },
              { href: '/more', label: 'More Styles' },
            ].map(item => (
              <Link key={item.href} href={item.href} className={`hdr-link${pathname === item.href ? ' active' : ''}`}>{item.label}</Link>
            ))}
          </nav>

          <form className="search" role="search" style={{ position: 'relative' }}
            onSubmit={e => { e.preventDefault(); setShowSuggest(false); if (search.trim()) router.push(`/products?q=${encodeURIComponent(search.trim())}`); }}>
            <span className="search-lens" aria-hidden="true">
              <svg viewBox="0 0 24 24" width="18" height="18"><path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" d="M11 5a6 6 0 1 0 0 12 6 6 0 0 0 0-12Zm4.5 10.5L20 20" /></svg>
            </span>
            <input
              id="searchInput"
              name="q"
              type="search"
              placeholder="Search by Keyword or Product ID"
              aria-label="Search products"
              value={search}
              autoComplete="off"
              onChange={e => { setSearch(e.target.value); setShowSuggest(true); runSuggest(e.target.value); }}
              onFocus={() => { if (suggestions.length) setShowSuggest(true); }}
              onBlur={() => setTimeout(() => setShowSuggest(false), 150)}
            />
            <button type="submit">Search</button>
            <div className="search-icons" aria-hidden="false">
              <button type="button" className="s-ic" aria-label="Voice search" title="Voice search"
                onClick={() => {
                  const SR:any=(window as any).webkitSpeechRecognition||(window as any).SpeechRecognition;
                  if(!SR){ document.getElementById('searchInput')?.focus(); return; }
                  try {
                    const r=new SR(); r.lang='en-IN'; r.interimResults=false;
                    r.onresult=(e:any)=>{ const t=e.results[0][0].transcript; setSearch(t); if(t.trim()) router.push(`/products?q=${encodeURIComponent(t.trim())}`); };
                    r.onerror=()=>{ document.getElementById('searchInput')?.focus(); };
                    r.start();
                  } catch { document.getElementById('searchInput')?.focus(); }
                }}>
                <svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M12 15a3 3 0 0 0 3-3V6a3 3 0 1 0-6 0v6a3 3 0 0 0 3 3Zm5-3a5 5 0 0 1-10 0H5a7 7 0 0 0 6 6.92V22h2v-3.08A7 7 0 0 0 19 12h-2Z"/></svg>
              </button>
            </div>

            {showSuggest && suggestions.length > 0 && (
              <div style={{
                position: 'absolute', top: 'calc(100% + 4px)', left: 0, right: 0, zIndex: 300,
                background: '#fff', border: '1px solid #eee', borderRadius: '10px',
                boxShadow: '0 8px 28px rgba(0,0,0,.14)', overflow: 'hidden',
              }}>
                {suggestions.map(p => {
                  const img = productImageSrc(p.image);
                  return (
                    <Link key={p.dbId} href={`/products/${productSlug(p.name, p.dbId)}`}
                      onClick={() => { setShowSuggest(false); setSearch(''); }}
                      style={{ display: 'flex', alignItems: 'center', gap: '.6rem', padding: '.5rem .7rem', textDecoration: 'none', color: '#1a1a1a', borderBottom: '1px solid #f5f5f5' }}>
                      {img && <Image src={img} alt="" width={38} height={38} sizes="38px" style={{ width: 38, height: 38, objectFit: 'cover', borderRadius: 6, flexShrink: 0, background: '#f6f6f6' }} />}
                      <span style={{ display: 'flex', flexDirection: 'column', minWidth: 0 }}>
                        <span style={{ fontSize: '.85rem', fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.name}</span>
                        <span style={{ fontSize: '.78rem', color: '#722f37', fontWeight: 700 }}>₹{finalUnitPrice(p).toLocaleString('en-IN')}</span>
                      </span>
                    </Link>
                  );
                })}
                <button type="submit"
                  style={{ width: '100%', textAlign: 'left', padding: '.55rem .7rem', background: '#faf6f2', border: 'none', color: '#722f37', fontWeight: 700, fontSize: '.82rem', cursor: 'pointer' }}>
                  See all results for “{search.trim()}” →
                </button>
              </div>
            )}
          </form>

          <div className="brand-actions">
            {/* Wishlist — icon button with count badge */}
            <Link className="hdr-ico-btn" href="/wishlist" aria-label="Wishlist" title="Wishlist">
              <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">
                <path fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"
                  d="M12 20.3S4.4 15.6 4.4 10.6a4.1 4.1 0 0 1 7.6-2.5 4.1 4.1 0 0 1 7.6 2.5c0 5-7.6 9.7-7.6 9.7Z" />
              </svg>
              {wishCount > 0 && <span className="hdr-badge">{wishCount}</span>}
            </Link>

            {/* Cart — solid brand pill */}
            <Link className="cart-link" href="/cart" aria-label="Cart">
              <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
                <path fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"
                  d="M2.5 3.5h2.2l2.1 10.3a1.6 1.6 0 0 0 1.6 1.3h8.3a1.6 1.6 0 0 0 1.6-1.3L20 6.6H5.6" />
                <circle cx="9.5" cy="19.5" r="1.4" fill="currentColor" />
                <circle cx="17" cy="19.5" r="1.4" fill="currentColor" />
              </svg>
              <span>Cart</span>
              {count > 0 && (
                <span className={`cart-count${cartBounce ? ' cart-bounce' : ''}`}>{count}</span>
              )}
            </Link>
            <style>{`
              @keyframes cartBounce {
                0%,100% { transform: scale(1); }
                30%      { transform: scale(1.5); }
                60%      { transform: scale(.85); }
                80%      { transform: scale(1.15); }
              }
              .cart-bounce { animation: cartBounce .6s ease; background: #27ae60 !important; color: #fff !important; }
            `}</style>

            {isLoggedIn ? (
              /* Account — avatar pill that opens a dropdown */
              <div className="acct-wrap" ref={acctRef}>
                <button type="button"
                  className={`acct-pill${acctMenu ? ' open' : ''}`}
                  onClick={() => setAcctMenu(o => !o)}
                  aria-haspopup="menu" aria-expanded={acctMenu}
                  aria-label="My Account" title="My Account">
                  <span className="acct-avatar">
                    {customerPhoto
                      ? <img src={customerPhoto} alt="" />
                      : (customerName ? customerName.charAt(0).toUpperCase() : 'U')}
                  </span>
                  <span className="acct-name">{customerFull || customerName || 'Account'}</span>
                  <svg className="acct-chev" viewBox="0 0 24 24" width="14" height="14" aria-hidden="true">
                    <path fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" d="m6 9 6 6 6-6" />
                  </svg>
                </button>

                {acctMenu && (
                  <div className="hdr-acct-menu" role="menu">
                    <div className="hdr-acct-menu-head">
                      <strong>{customerFull || customerName || 'My Account'}</strong>
                      {customerPhone && <span>{customerPhone}</span>}
                    </div>

                    <Link className="hdr-acct-menu-item" role="menuitem" href="/account" onClick={() => setAcctMenu(false)}>
                      <svg viewBox="0 0 24 24" width="19" height="19" aria-hidden="true">
                        <rect x="3.2" y="3.2" width="7.4" height="7.4" rx="1.8" fill="none" stroke="currentColor" strokeWidth="1.7" />
                        <rect x="13.4" y="3.2" width="7.4" height="7.4" rx="1.8" fill="none" stroke="currentColor" strokeWidth="1.7" />
                        <rect x="3.2" y="13.4" width="7.4" height="7.4" rx="1.8" fill="none" stroke="currentColor" strokeWidth="1.7" />
                        <rect x="13.4" y="13.4" width="7.4" height="7.4" rx="1.8" fill="none" stroke="currentColor" strokeWidth="1.7" />
                      </svg>
                      <span><b>Dashboard</b><small>Wallet, Refer &amp; Earn, Wishlist &amp; more</small></span>
                    </Link>

                    <Link className="hdr-acct-menu-item" role="menuitem" href="/orders" onClick={() => setAcctMenu(false)}>
                      <svg viewBox="0 0 24 24" width="19" height="19" aria-hidden="true">
                        <path fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"
                          d="M20.5 7.5 12 3 3.5 7.5v9L12 21l8.5-4.5v-9ZM3.7 7.6 12 12l8.3-4.4M12 12v9" />
                      </svg>
                      <span><b>My Orders</b><small>View and track your orders</small></span>
                    </Link>

                    <Link className="hdr-acct-menu-item" role="menuitem" href="/account/address" onClick={() => setAcctMenu(false)}>
                      <svg viewBox="0 0 24 24" width="19" height="19" aria-hidden="true">
                        <path fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"
                          d="M12 21.5s7-5.6 7-11a7 7 0 1 0-14 0c0 5.4 7 11 7 11Z" />
                        <circle cx="12" cy="10.2" r="2.6" fill="none" stroke="currentColor" strokeWidth="1.7" />
                      </svg>
                      <span><b>My Address</b><small>Manage delivery addresses</small></span>
                    </Link>

                    <Link className="hdr-acct-menu-item" role="menuitem" href="/account/edit" onClick={() => setAcctMenu(false)}>
                      <svg viewBox="0 0 24 24" width="19" height="19" aria-hidden="true">
                        <circle cx="12" cy="8.2" r="3.7" fill="none" stroke="currentColor" strokeWidth="1.7" />
                        <path fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"
                          d="M4.8 20.2c0-3.4 3.2-6 7.2-6s7.2 2.6 7.2 6" />
                      </svg>
                      <span><b>Edit Profile</b><small>Update your details</small></span>
                    </Link>

                    <div className="hdr-acct-menu-sep" />

                    <button type="button" className="hdr-acct-menu-item hdr-acct-menu-danger" role="menuitem"
                      onClick={() => { logout(); resetLoginForm(); setAcctMenu(false); window.dispatchEvent(new Event('auth-changed')); router.push('/account'); }}>
                      <svg viewBox="0 0 24 24" width="19" height="19" aria-hidden="true">
                        <path fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"
                          d="M15 4.5h3.5A1.5 1.5 0 0 1 20 6v12a1.5 1.5 0 0 1-1.5 1.5H15M10 16l-4-4 4-4M6 12h10" />
                      </svg>
                      <span><b>Logout</b><small>Logout from your account</small></span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button type="button" className="account-cta account-ico" onClick={openLogin}
                aria-label="Login / Signup" title="Login / Signup">
                <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm0 2c-3.9 0-7 2.2-7 5v1h14v-1c0-2.8-3.1-5-7-5Z" /></svg>
                <span>Login</span>
              </button>
            )}
          </div>
        </div>

      </header>
      </div>{/* /m-head sticky wrapper */}

      {/* Department Nav — sticky independently so only icons bar stays fixed on scroll */}
      <nav className="department-nav" aria-label="Shop by department">
        {/* Hamburger button — always visible in sticky bar */}
        <button
          className="dept-nav-menu-btn"
          onClick={() => setMenuOpen(v => !v)}
          aria-label="Open menu"
          style={{
            display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
            gap: '.08rem', padding: '.6rem .75rem', background: 'none', border: 'none',
            cursor: 'pointer', color: 'var(--brand)', flexShrink: 0,
            borderRight: '1px solid var(--border)', marginRight: '.25rem',
            minWidth: 52,
          }}>
          <span style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            <span style={{ display: 'block', width: 20, height: 2, background: 'currentColor', borderRadius: 2 }} />
            <span style={{ display: 'block', width: 20, height: 2, background: 'currentColor', borderRadius: 2 }} />
            <span style={{ display: 'block', width: 20, height: 2, background: 'currentColor', borderRadius: 2 }} />
          </span>
          <span style={{ fontSize: '.72rem', fontWeight: 500, whiteSpace: 'nowrap', marginTop: '.15rem' }}>Menu</span>
        </button>

        {[
          { href: '/', img: '/nav-icons/home.webp', emoji: '🏠', label: 'Home' },
          { href: '/best-sellers', img: '/nav-icons/best-sellers.webp', emoji: '⭐', label: 'Best Sellers' },
          { href: '/women', img: '/nav-icons/women.webp', emoji: '👩', label: 'Women' },
          { href: '/men', img: '/nav-icons/men.webp', emoji: '👔', label: 'Men' },
          { href: '/kids', img: '/nav-icons/kids.webp', emoji: '👶', label: 'Kids' },
          { href: '/beauty', img: '/nav-icons/beauty.webp', emoji: '💄', label: 'Beauty' },
          { href: '/fabrics', img: '/nav-icons/fabrics.webp', emoji: '🧵', label: 'Fabrics' },
          { href: '/more', img: '/nav-icons/more.webp', emoji: '🛍️', label: 'More Styles' },
        ].map(item => (
          <Link key={item.href} href={item.href} className={`dept-link${pathname === item.href ? ' active' : ''}`} style={{ display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", minWidth: 60 }}>
            <span>{item.label}</span>
          </Link>
        ))}

        {/* Desktop: search bar appears after "More Styles" once the page is scrolled */}
        <form className={`dept-search${scrolled ? ' show' : ''}`} role="search"
          onSubmit={e => { e.preventDefault(); if (search.trim()) router.push(`/products?q=${encodeURIComponent(search.trim())}`); }}>
          <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" d="M11 5a6 6 0 1 0 0 12 6 6 0 0 0 0-12Zm4.5 10.5L20 20" /></svg>
          <input type="search" placeholder="Search products…" aria-label="Search products"
            value={search} onChange={e => setSearch(e.target.value)} />
        </form>
      </nav>

      {/* Mobile Account Drawer — opened by the bottom-nav "Account" button. */}
      {accountOpen && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 500 }}>
          <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,.5)' }} onClick={() => setAccountOpen(false)} />
          <nav style={{ position: 'absolute', top: 0, right: 0, bottom: 0, width: '286px', background: '#fff', padding: '1.25rem 0', overflowY: 'auto', boxShadow: '-4px 0 16px rgba(0,0,0,.15)' }}>
            <div style={{ padding: '0 1.25rem 1rem', borderBottom: '1px solid #eee', marginBottom: '.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <strong style={{ color: '#722f37', fontSize: '1.05rem' }}>{isLoggedIn && customerName ? `Hi, ${customerName}` : 'My Account'}</strong>
              <button onClick={() => setAccountOpen(false)} aria-label="Close account" style={{ background: 'none', border: 'none', fontSize: '1.3rem', cursor: 'pointer', color: '#888' }}><span aria-hidden="true">✕</span></button>
            </div>
            {isLoggedIn ? (
              <div style={{ padding: '0 1.25rem' }}>
                {[
                  { href: '/account', label: '🏠 Dashboard' },
                  { href: '/orders', label: '📦 My Orders' },
                  { href: '/account/wallet', label: '👛 My Wallet' },
                  { href: '/account/refer', label: '🤝 Refer & Earn' },
                  { href: '/wishlist', label: '❤️ Wishlist' },
                  { href: '/cart', label: '🛒 Cart' },
                  { href: '/account/address', label: '📍 My Address' },
                  { href: '/account/edit', label: '✏️ Edit Profile' },
                  { href: '/account/pan', label: '🪪 PAN Card' },
                  { href: '/account/newsletter', label: '📧 Newsletter' },
                  { href: '/account/saved-cards', label: '💳 Saved Cards' },
                  { href: '/account/downloads', label: '📥 Downloads' },
                  { href: '/reviews', label: '⭐ My Reviews' },
                ].map(l => (
                  <Link key={l.href + l.label} href={l.href} onClick={() => setAccountOpen(false)}
                    style={{ display: 'block', padding: '.6rem .25rem', color: '#444', fontSize: '.92rem', textDecoration: 'none', borderBottom: '1px solid #f5f5f5' }}>
                    {l.label}
                  </Link>
                ))}
                <button type="button"
                  onClick={() => { logout(); resetLoginForm(); setAccountOpen(false); window.dispatchEvent(new Event('auth-changed')); router.push('/account'); }}
                  style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '.4rem', width: '100%', padding: '.65rem', color: '#fff', fontSize: '.92rem', background: '#722f37', border: 'none', borderRadius: '10px', cursor: 'pointer', fontWeight: 700, margin: '.8rem 0 .3rem' }}>
                  🔓 Logout
                </button>
              </div>
            ) : (
              <div style={{ padding: '0 1.25rem' }}>
                <button type="button" onClick={() => { setAccountOpen(false); openLogin(); }}
                  style={{ display: 'block', width: '100%', padding: '.72rem', color: '#fff', fontSize: '.95rem', background: '#722f37', border: 'none', borderRadius: '10px', cursor: 'pointer', fontWeight: 700, marginBottom: '.8rem' }}>
                  🔑 Login / Signup
                </button>
                <Link href="/wishlist" onClick={() => setAccountOpen(false)} style={{ display: 'block', padding: '.6rem .25rem', color: '#444', fontSize: '.92rem', textDecoration: 'none', borderBottom: '1px solid #f5f5f5' }}>❤️ Wishlist</Link>
                <Link href="/cart" onClick={() => setAccountOpen(false)} style={{ display: 'block', padding: '.6rem .25rem', color: '#444', fontSize: '.92rem', textDecoration: 'none', borderBottom: '1px solid #f5f5f5' }}>🛒 Cart ({count})</Link>
                <Link href="/tracking" onClick={() => setAccountOpen(false)} style={{ display: 'block', padding: '.6rem .25rem', color: '#444', fontSize: '.92rem', textDecoration: 'none', borderBottom: '1px solid #f5f5f5' }}>🚚 Track Order</Link>
              </div>
            )}
          </nav>
        </div>
      )}

      {/* Mobile Categories Drawer — opened by the bottom-nav "Categories" button.
          Shows the old department-nav links (not the account menu). */}
      {catOpen && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 500 }}>
          <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,.5)' }} onClick={() => setCatOpen(false)} />
          <nav style={{
            position: 'absolute', top: 0, left: 0, bottom: 0, width: '278px',
            background: '#fff', padding: '1.25rem 0', overflowY: 'auto',
            boxShadow: '4px 0 16px rgba(0,0,0,.15)',
          }}>
            <div style={{ padding: '0 1.25rem 1rem', borderBottom: '1px solid #eee', marginBottom: '.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <strong style={{ color: '#722f37', fontSize: '1.05rem' }}>Categories</strong>
              <button onClick={() => setCatOpen(false)} aria-label="Close categories" style={{ background: 'none', border: 'none', fontSize: '1.3rem', cursor: 'pointer', color: '#888' }}><span aria-hidden="true">✕</span></button>
            </div>
            <div style={{ padding: '0 1.25rem' }}>
              {[
                { href: '/', label: 'Home' },
                { href: '/best-sellers', label: 'Best Sellers' },
                { href: '/women', label: 'Women' },
                { href: '/men', label: 'Men' },
                { href: '/kids', label: 'Kids' },
                { href: '/beauty', label: 'Beauty' },
                { href: '/fabrics', label: 'Fabrics' },
                { href: '/more', label: 'More Styles' },
              ].map(l => (
                <Link key={l.href} href={l.href} onClick={() => setCatOpen(false)}
                  style={{ display: 'block', padding: '.72rem .25rem', color: '#333', fontSize: '.95rem', textDecoration: 'none', fontWeight: 600, borderBottom: '1px solid #f5f5f5' }}>
                  {l.label}
                </Link>
              ))}
            </div>
          </nav>
        </div>
      )}

      {/* Mobile Menu Drawer */}
      {menuOpen && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 500 }}>
          <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,.5)' }} onClick={() => setMenuOpen(false)} />
          <nav style={{
            position: 'absolute', top: 0, left: 0, bottom: 0, width: '280px',
            background: '#fff', padding: '1.5rem 0', overflowY: 'auto',
            boxShadow: '4px 0 16px rgba(0,0,0,.15)',
          }}>
            <div style={{ padding: '0 1.25rem 1rem', borderBottom: '1px solid #eee', marginBottom: '1rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <strong style={{ color: '#722f37' }}>Mahalaxmi Fashion Hub</strong>
              <button onClick={() => setMenuOpen(false)} aria-label="Close menu" style={{ background: 'none', border: 'none', fontSize: '1.3rem', cursor: 'pointer', color: '#888' }}><span aria-hidden="true">✕</span></button>
            </div>

            {isLoggedIn ? (
              <div style={{ padding: '0 1.25rem 1rem', borderBottom: '1px solid #eee', marginBottom: '1rem' }}>
                <p style={{ fontSize: '.75rem', fontWeight: 700, color: '#aaa', textTransform: 'uppercase', letterSpacing: '.05em', marginBottom: '.25rem' }}>My Account</p>
                {customerName && <p style={{ fontSize: '.85rem', fontWeight: 600, color: '#722f37', marginBottom: '.5rem' }}>👋 {customerName}</p>}
                {[
                  { href: '/account', label: '🏠 Dashboard' },
                  { href: '/orders', label: '📦 My Orders' },
                  { href: '/account/wallet', label: '👛 My Wallet' },
                  { href: '/account/refer', label: '🤝 Refer & Earn' },
                  { href: '/wishlist', label: '❤️ Wishlist' },
                  { href: '/cart', label: '🛒 Cart' },
                  { href: '/account/address', label: '📍 My Address' },
                  { href: '/account/edit', label: '✏️ Edit Profile' },
                  { href: '/account/pan', label: '🪪 PAN Card' },
                  { href: '/account/newsletter', label: '📧 Newsletter' },
                  { href: '/account/saved-cards', label: '💳 Saved Cards' },
                  { href: '/account/downloads', label: '📥 Downloads' },
                  { href: '/reviews', label: '⭐ My Reviews' },
                ].map(l => (
                  <Link key={l.href + l.label} href={l.href} onClick={() => setMenuOpen(false)}
                    style={{ display: 'block', padding: '.45rem .25rem', color: '#555', fontSize: '.9rem', textDecoration: 'none' }}>
                    {l.label}
                  </Link>
                ))}
                <div style={{ borderTop: '1px solid #f0f0f0', marginTop: '.5rem', paddingTop: '.5rem' }}>
                  <button type="button"
                    onClick={() => { logout(); resetLoginForm(); setMenuOpen(false); window.dispatchEvent(new Event('auth-changed')); router.push('/account'); }}
                    style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '.4rem', width: '100%', textAlign: 'center', padding: '.6rem .25rem', color: '#fff', fontSize: '.92rem', background: '#722f37', border: 'none', borderRadius: '10px', cursor: 'pointer', fontWeight: 700, marginBottom: '.4rem' }}>
                    🔓 Logout
                  </button>
                  <Link href="/account/deactivate" onClick={() => setMenuOpen(false)}
                    style={{ display: 'block', padding: '.4rem .25rem', color: '#c0392b', fontSize: '.82rem', textDecoration: 'none' }}>
                    ⏸️ Deactivate Account
                  </Link>
                  <Link href="/account/delete" onClick={() => setMenuOpen(false)}
                    style={{ display: 'block', padding: '.4rem .25rem', color: '#c0392b', fontSize: '.82rem', textDecoration: 'none' }}>
                    🗑️ Delete Account
                  </Link>
                </div>
              </div>
            ) : (
              <div style={{ padding: '0 1.25rem 1rem', borderBottom: '1px solid #eee', marginBottom: '1rem' }}>
                <button type="button" onClick={openLogin}
                  style={{ display: 'block', width: '100%', textAlign: 'left', padding: '.5rem', color: '#722f37', fontSize: '.95rem', background: 'none', border: 'none', cursor: 'pointer', fontWeight: 700 }}>
                  🔑 Login / Signup
                </button>
                <Link href="/wishlist" onClick={() => setMenuOpen(false)}
                  style={{ display: 'block', padding: '.5rem', color: '#555', fontSize: '.9rem', textDecoration: 'none' }}>❤️ Wishlist</Link>
                <Link href="/cart" onClick={() => setMenuOpen(false)}
                  style={{ display: 'block', padding: '.5rem', color: '#555', fontSize: '.9rem', textDecoration: 'none' }}>🛒 Cart ({count})</Link>
                <Link href="/tracking" onClick={() => setMenuOpen(false)}
                  style={{ display: 'block', padding: '.5rem', color: '#555', fontSize: '.9rem', textDecoration: 'none' }}>🚚 Track Order</Link>
              </div>
            )}

            <div style={{ padding: '0 1.25rem' }}>
              <p style={{ fontSize: '.75rem', fontWeight: 700, color: '#aaa', textTransform: 'uppercase', letterSpacing: '.05em', marginBottom: '.5rem' }}>Shop by Category</p>
              {[
                { href: '/', label: 'Home' },
                { href: '/best-sellers', label: 'Best Sellers' },
                { href: '/women', label: 'Women' },
                { href: '/men', label: 'Men' },
                { href: '/kids', label: 'Kids' },
                { href: '/beauty', label: 'Beauty' },
                { href: '/fabrics', label: 'Fabrics' },
                { href: '/more', label: 'More Styles' },
              ].map(l => (
                <Link key={l.href} href={l.href} onClick={() => setMenuOpen(false)}
                  style={{ display: 'block', padding: '.5rem', color: '#333', fontSize: '.9rem', textDecoration: 'none', fontWeight: 500 }}>
                  {l.label}
                </Link>
              ))}
            </div>

            <div style={{ padding: '1rem 1.25rem 0', borderTop: '1px solid #eee', marginTop: '1rem' }}>
              <p style={{ fontSize: '.75rem', fontWeight: 700, color: '#aaa', textTransform: 'uppercase', letterSpacing: '.05em', marginBottom: '.5rem' }}>Help &amp; Policies</p>
              {[
                { href: '/cancellation-policy', label: 'Cancellation Policy' },
                { href: '/return-policy', label: 'Return Policy' },
                { href: '/return-exchange', label: 'Refund & Exchange' },
                { href: '/privacy-policy', label: 'Privacy Policy' },
                { href: '/safety-center', label: 'Safety Center' },
                { href: '/contact', label: 'Contact Us' },
                { href: 'https://affiliate.mahalaxmifashionhub.com/', label: '💸 Earn With Us' },
              ].map(l => (
                <Link key={l.href} href={l.href} onClick={() => setMenuOpen(false)}
                  style={{ display: 'block', padding: '.4rem', color: l.href.startsWith('http') ? '#722f37' : '#666', fontWeight: l.href.startsWith('http') ? 700 : 400, fontSize: '.85rem', textDecoration: 'none' }}>
                  {l.label}
                </Link>
              ))}
            </div>
          </nav>
        </div>
      )}

      {loginOpen && (
        <div
          onClick={closeLogin}
          style={{ position: 'fixed', inset: 0, zIndex: 900, background: 'rgba(0,0,0,.62)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem' }}>
          <style>{`
            .mfh-login-modal {
              width: 100%; max-width: 640px; background: #fff; border-radius: 20px;
              box-shadow: 0 24px 80px rgba(0,0,0,.3); padding: 0;
              position: relative; display: grid; grid-template-columns: 240px 1fr;
              gap: 0; align-items: stretch; overflow: hidden;
            }
            .mfh-login-logo {
              background: linear-gradient(160deg, #722f37 0%, #722f37 100%);
              display: flex; flex-direction: column; align-items: center;
              justify-content: center; padding: 2rem 1.25rem; text-align: center; gap: .75rem;
            }
            .mfh-login-logo img {
              width: 175px; height: 175px; max-width: 175px; flex-shrink: 0;
              border-radius: 50%; padding: 22px; box-sizing: border-box;
              background: #fff; object-fit: contain; display: block;
            }
            .mfh-login-logo p {
              margin: 0; color: #fff; font-weight: 800; font-size: 1rem; line-height: 1.3;
              letter-spacing: .01em;
            }
            .mfh-login-logo small {
              color: rgba(255,255,255,.7); font-size: .75rem; margin-top: .25rem; display: block;
            }
            .mfh-login-form { padding: 2rem 2rem; }
            @media (max-width: 520px) {
              .mfh-login-modal { grid-template-columns: 1fr !important; border-radius: 16px !important; }
              .mfh-login-logo {
                flex-direction: row !important; padding: 1rem 1.25rem !important;
                justify-content: flex-start !important; gap: .75rem !important;
              }
              .mfh-login-logo img { width: 96px !important; height: 96px !important; padding: 12px !important; border-radius: 50% !important; }
              .mfh-login-logo p { font-size: .9rem !important; text-align: left !important; }
              .mfh-login-logo small { display: none !important; }
              .mfh-login-form { padding: 1.25rem !important; }
            }
          `}</style>
          <div
            onClick={e => e.stopPropagation()}
            className="mfh-login-modal">
            <button onClick={closeLogin} aria-label="Close login"
              style={{ position: 'absolute', right: 14, top: 14, background: 'rgba(0,0,0,.15)', border: 'none', color: '#fff', fontSize: '1.2rem', cursor: 'pointer', lineHeight: 1, zIndex: 10, width: 30, height: 30, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              ×
            </button>
            <div className="mfh-login-logo">
              <Image src="/logo.webp" alt="Mahalaxmi Fashion Hub" width={547} height={300} sizes="200px" />
            </div>
            <form onSubmit={handleLogin} className="mfh-login-form" style={{ display: 'flex', flexDirection: 'column', gap: '.9rem' }}>
              <h2 style={{ margin: 0, fontSize: '1.6rem', fontWeight: 800, color: '#1a1a1a' }}>Welcome Back</h2>
              <p style={{ margin: '-.4rem 0 .2rem', fontSize: '.85rem', color: '#888' }}>Login to your account</p>
              {loginMode === 'password' ? (
                <>
                  <input type="email" required placeholder="Email" autoComplete="email"
                    value={loginForm.email}
                    onChange={e => setLoginForm(f => ({ ...f, email: e.target.value }))}
                    style={{ height: 54, border: '1.5px solid #ddd', borderRadius: 9, padding: '0 1rem', fontSize: '1.05rem', background: '#fff', boxSizing: 'border-box' }} />
                  <input type={showPassword ? 'text' : 'password'} required placeholder="Password" autoComplete="current-password"
                    value={loginForm.password}
                    onChange={e => setLoginForm(f => ({ ...f, password: e.target.value }))}
                    style={{ height: 52, border: '1.5px solid #ddd', borderRadius: 9, padding: '0 1rem', fontSize: '1.05rem', background: '#fff', boxSizing: 'border-box' }} />
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '1rem', color: '#555', fontSize: '.95rem' }}>
                    <label style={{ display: 'flex', alignItems: 'center', gap: '.5rem', cursor: 'pointer' }}>
                      <input type="checkbox" checked={showPassword} onChange={e => setShowPassword(e.target.checked)} />
                      Show Password
                    </label>
                    <Link href="/forgot-password" onClick={closeLogin} style={{ color: '#a01836', textDecoration: 'none' }}>Forgot?</Link>
                  </div>
                  {loginError && <p style={{ margin: 0, color: '#c0392b', fontSize: '.85rem', fontWeight: 600 }}>{loginError}</p>}
                  <button type="submit" disabled={loginLoading}
                    style={{ height: 54, border: 'none', borderRadius: 9, background: '#a01836', color: '#fff', fontWeight: 800, fontSize: '1.05rem', cursor: loginLoading ? 'not-allowed' : 'pointer', opacity: loginLoading ? .7 : 1 }}>
                    {loginLoading ? 'Logging in...' : 'Login'}
                  </button>
                  <p style={{ margin: '.6rem 0 0', textAlign: 'center', color: '#666' }}>
                    New customer? <Link href="/account/register" onClick={closeLogin} style={{ color: '#a01836', fontWeight: 800, textDecoration: 'none' }}>Create New Account</Link>
                  </p>
                </>
              ) : (
                <>
                  <p style={{ margin: '-.2rem 0 0', fontSize: '.9rem', color: '#555' }}>Login with a code sent to your mobile or email.</p>
                  <div style={{ display: 'flex', alignItems: 'stretch', border: '1.5px solid #ddd', borderRadius: 9, background: otpSent ? '#f7f7f7' : '#fff', overflow: 'hidden' }}>
                    {/^\d/.test(otpContact.trim()) && (
                      <span style={{ display: 'flex', alignItems: 'center', padding: '0 .5rem 0 1rem', fontSize: '1.05rem', fontWeight: 600, color: '#333', background: '#fafafa', borderRight: '1px solid #eee' }}>+91</span>
                    )}
                    <input type="text" placeholder="Mobile number or Email" autoComplete="username"
                      value={otpContact}
                      onChange={e => {
                        const raw = e.target.value;
                        const first = raw.trim()[0];
                        if (first && /[0-9]/.test(first)) setOtpContact(raw.replace(/\D/g, '').slice(0, 10));
                        else setOtpContact(raw);
                      }}
                      disabled={otpSent}
                      onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); otpSent ? handleVerifyOtp() : handleSendOtp(); } }}
                      style={{ flex: 1, height: 54, border: 'none', outline: 'none', padding: '0 1rem', fontSize: '1.05rem', background: 'transparent', boxSizing: 'border-box' }} />
                  </div>
                  {otpSent && (
                    <input type="text" inputMode="numeric" placeholder="Enter OTP" autoFocus
                      value={otpCode}
                      onChange={e => setOtpCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                      onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); handleVerifyOtp(); } }}
                      style={{ height: 54, border: '1.5px solid #ddd', borderRadius: 9, padding: '0 1rem', fontSize: '1.15rem', letterSpacing: '.2em', textAlign: 'center', background: '#fff', boxSizing: 'border-box' }} />
                  )}
                  {otpMsg && <p style={{ margin: 0, color: otpMsg.startsWith('OTP sent') ? '#2e7d32' : '#c0392b', fontSize: '.85rem', fontWeight: 600 }}>{otpMsg}</p>}
                  {!otpSent ? (
                    <button type="button" onClick={handleSendOtp} disabled={otpLoading}
                      style={{ height: 54, border: 'none', borderRadius: 9, background: '#a01836', color: '#fff', fontWeight: 800, fontSize: '1.05rem', cursor: otpLoading ? 'not-allowed' : 'pointer', opacity: otpLoading ? .7 : 1 }}>
                      {otpLoading ? 'Sending...' : 'Send OTP'}
                    </button>
                  ) : (
                    <button type="button" onClick={handleVerifyOtp} disabled={otpLoading}
                      style={{ height: 54, border: 'none', borderRadius: 9, background: '#a01836', color: '#fff', fontWeight: 800, fontSize: '1.05rem', cursor: otpLoading ? 'not-allowed' : 'pointer', opacity: otpLoading ? .7 : 1 }}>
                      {otpLoading ? 'Verifying...' : 'Verify & Login'}
                    </button>
                  )}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '.85rem' }}>
                    {otpSent ? (
                      <button type="button" onClick={handleSendOtp} disabled={otpLoading} style={{ background: 'none', border: 'none', color: '#a01836', fontWeight: 600, cursor: 'pointer', padding: 0 }}>Resend OTP</button>
                    ) : <span />}
                    <button type="button" onClick={switchToPassword} style={{ background: 'none', border: 'none', color: '#666', fontWeight: 600, cursor: 'pointer', padding: 0 }}>← Password login</button>
                  </div>
                </>
              )}

              {/* Social Login Buttons — always visible */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '.75rem', margin: '.25rem 0' }}>
                <div style={{ flex: 1, height: '1px', background: '#e0e0e0' }} />
                <span style={{ fontSize: '.78rem', color: '#aaa', whiteSpace: 'nowrap' }}>or continue with</span>
                <div style={{ flex: 1, height: '1px', background: '#e0e0e0' }} />
              </div>
              <div style={{ display: 'flex', gap: '.6rem' }}>
                {/* Google */}
                {googleClientId ? (
                  <a href={`https://accounts.google.com/o/oauth2/v2/auth?client_id=${googleClientId}&redirect_uri=${encodeURIComponent(typeof window !== 'undefined' ? window.location.origin + '/account/social-callback' : '')}&response_type=code&scope=email%20profile&prompt=select_account&state=google`}
                    title="Continue with Google"
                    style={{ flex: 1, height: 46, borderRadius: 9, background: '#fff', color: '#333', fontWeight: 700, fontSize: '.82rem', whiteSpace: 'nowrap', textDecoration: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '.4rem', border: '1.5px solid #ddd', cursor: 'pointer' }}>
                    <svg width="18" height="18" viewBox="0 0 48 48" style={{ flexShrink: 0 }}><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>
                    Google
                  </a>
                ) : (
                  <button type="button" disabled title="Google login not configured"
                    style={{ flex: 1, height: 46, borderRadius: 9, background: '#f5f5f5', color: '#bbb', fontWeight: 700, fontSize: '.85rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '.4rem', border: '1.5px solid #eee', cursor: 'not-allowed' }}>
                    <svg width="18" height="18" viewBox="0 0 48 48"><path fill="#ccc" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#ccc" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#ccc" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#ccc" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>
                    Google
                  </button>
                )}

                {/* Mobile / Email OTP */}
                <button type="button" onClick={switchToOtp} title="Login with Mobile or Email OTP"
                  style={{ flex: 1, height: 46, borderRadius: 9, background: loginMode === 'otp' ? '#f7eff0' : '#fff', color: '#a01836', fontWeight: 700, fontSize: '.82rem', whiteSpace: 'nowrap', letterSpacing: '-.01em', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '.4rem', border: '1.5px solid #ddd', cursor: 'pointer' }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}><rect x="6" y="2" width="12" height="20" rx="2.6" stroke="#a01836" strokeWidth="1.7"/><line x1="10.4" y1="5" x2="13.6" y2="5" stroke="#a01836" strokeWidth="1.7" strokeLinecap="round"/><circle cx="12" cy="18.6" r="1" fill="#a01836"/></svg>
                  Mobile
                </button>

                {/* Facebook */}
                {facebookAppId ? (
                  <a href={`https://www.facebook.com/v18.0/dialog/oauth?client_id=${facebookAppId}&redirect_uri=${encodeURIComponent(typeof window !== 'undefined' ? window.location.origin + '/account/social-callback' : '')}&scope=email,public_profile&response_type=code&state=facebook`}
                    title="Continue with Facebook"
                    style={{ flex: 1, height: 46, borderRadius: 9, background: '#fff', color: '#333', fontWeight: 700, fontSize: '.82rem', whiteSpace: 'nowrap', textDecoration: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '.4rem', border: '1.5px solid #ddd', cursor: 'pointer' }}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="#1877f2" style={{ flexShrink: 0 }}><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                    Facebook
                  </a>
                ) : (
                  <button type="button" disabled title="Facebook login not configured"
                    style={{ flex: 1, height: 46, borderRadius: 9, background: '#f5f5f5', color: '#bbb', fontWeight: 700, fontSize: '.85rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '.4rem', border: '1.5px solid #eee', cursor: 'not-allowed' }}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="#ccc"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                    Facebook
                  </button>
                )}
              </div>
            </form>
          </div>
        </div>
      )}

    </>
  );
}
