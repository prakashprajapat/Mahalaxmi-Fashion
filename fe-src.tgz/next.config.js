const path = require('path');
/** @type {import('next').NextConfig} */
const nextConfig = {
  poweredByHeader: false,
  ...(process.env.NEXT_OUTPUT_STANDALONE === 'true' ? { output: 'standalone' } : {}),
  // CQ-1: Build errors should surface — removed ignoreBuildErrors and ignoreDuringBuilds
  typescript: { ignoreBuildErrors: false },
  eslint: { ignoreDuringBuilds: false },
  webpack: (config) => {
    config.resolve.alias['@'] = path.resolve(__dirname);
    return config;
  },
  // CQ-2: Specific allowed image domains instead of wildcard **
  images: {
    formats: ['image/avif', 'image/webp'],
    // Every product photo filename ends in the millisecond it was uploaded, so
    // a given URL can never point at different bytes. A one-day TTL meant the
    // optimiser went STALE daily and re-resized all 84 photos to produce the
    // same output; 30 days stops that.
    minimumCacheTTL: 2592000,
    remotePatterns: [
      { protocol: 'https', hostname: '*.cloudinary.com' },
      { protocol: 'https', hostname: '*.amazonaws.com' },
      { protocol: 'https', hostname: 'mahalaxmifashionhub.com' },
      { protocol: 'https', hostname: '*.mahalaxmifashionhub.com' },
      { protocol: 'http', hostname: 'localhost' },
    ],
  },
  async rewrites() {
    return [
      {
        source: '/api/:path*',
        destination: `${process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:5000/api'}/:path*`,
      },
    ];
  },
  async headers() {
    return [
      {
        // Static images: cache 7 days at the browser/CDN edge, then revalidate in
        // the background. Product photos rarely change under the same filename.
        source: '/:all*(svg|jpg|jpeg|png|webp|avif|gif|ico)',
        headers: [
          { key: 'Cache-Control', value: 'public, max-age=604800, stale-while-revalidate=86400' },
        ],
      },
      {
        source: '/:path*',
        headers: [
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
          { key: 'Strict-Transport-Security', value: 'max-age=31536000; includeSubDomains; preload' },
          // Content-Security-Policy: XSS defense-in-depth. Allowlists exactly the external
          // sources this site uses — GA4/GTM, Meta Pixel, Razorpay checkout, Cloudinary/HTTPS
          // images, Google Fonts. 'unsafe-inline' is required because the app uses inline
          // <script> (GA/GTM/FB init) and many inline style props; even so, this still blocks
          // arbitrary external scripts, clickjacking (frame-ancestors), and forces HTTPS.
          // If a feature breaks after deploy, the browser console names the blocked source —
          // add its domain to the matching directive below.
          {
            key: 'Content-Security-Policy',
            value: [
              "default-src 'self'",
              // googleadservices + googleads.g.doubleclick are the Google Ads
              // conversion and remarketing tag. They were missing, so every
              // conversion the shop paid for was blocked at the browser before
              // it could be counted — the console said so on every page load,
              // under four React errors that turned out to be harmless.
              "script-src 'self' 'unsafe-inline' https://www.googletagmanager.com https://www.google-analytics.com https://www.googleadservices.com https://googleads.g.doubleclick.net https://checkout.razorpay.com https://cdn.razorpay.com https://connect.facebook.net https://static.cloudflareinsights.com https://sdk.cashfree.com",
              "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
              "font-src 'self' data: https://fonts.gstatic.com",
              "img-src 'self' data: blob: https:",
              "connect-src 'self' https://www.google-analytics.com https://region1.google-analytics.com https://analytics.google.com https://www.googletagmanager.com https://api.razorpay.com https://lumberjack.razorpay.com https://connect.facebook.net https://*.facebook.com https://static.cloudflareinsights.com https://*.merchant-center-analytics.goog https://*.google.com https://*.cashfree.com https://sdk.cashfree.com https://stats.g.doubleclick.net https://*.g.doubleclick.net https://www.googleadservices.com https://ad.doubleclick.net",
              "frame-src https://checkout.razorpay.com https://api.razorpay.com https://*.razorpay.com https://*.cashfree.com https://sdk.cashfree.com https://www.google.com https://maps.google.com",
              "object-src 'none'",
              "base-uri 'self'",
              "form-action 'self' https://*.cashfree.com https://payments.cashfree.com https://sandbox.cashfree.com https://*.razorpay.com https://api.razorpay.com",
              "frame-ancestors 'none'",
              "upgrade-insecure-requests",
            ].join('; '),
          },
        ],
      },
    ];
  },
  async redirects() {
    const legacy = [
      ['index.html', '/'],
      ['about-us.html', '/about-us'],
      ['contact.html', '/contact'],
      ['best-sellers.html', '/best-sellers'],
      ['saree.html', '/products?category=saree'],
      ['women.html', '/women'],
      ['men.html', '/men'],
      ['nighty.html', '/products?category=nighty'],
      ['petticoat.html', '/products?category=petticoat'],
      ['popline.html', '/products?category=popline'],
      ['nighty-cloth.html', '/products?category=nighty-cloth'],
      ['products.php', '/products'],
      ['wishlist.html', '/wishlist'],
      ['tracking.html', '/tracking'],
      ['checkout-shipping.html', '/checkout'],
      ['checkout-payment.html', '/checkout'],
      ['create-account.html', '/account/register'],
      ['customer-account.html', '/account'],
      ['account-edit.html', '/account/edit'],
      ['address-new.html', '/account/address'],
      ['order-history.html', '/orders'],
      ['downloadable-products.html', '/account/downloads'],
      ['newsletter-manage.html', '/account/newsletter'],
      ['saved-cards.html', '/account/saved-cards'],
      ['reviews.html', '/reviews'],
      ['privacy-policy.html', '/privacy-policy'],
      ['return-policy.html', '/return-policy'],
      ['return-exchange.html', '/return-exchange'],
      ['cancellation-policy.html', '/cancellation-policy'],
      ['shipping-delivery-policy.html', '/shipping-delivery-policy'],
      ['terms-conditions.html', '/terms-conditions'],
      ['safety-center.html', '/safety-center'],
      ['admin-login.html', '/admin/login'],
      ['admin.html', '/admin'],
      ['admin-orders.html', '/admin/orders'],
      ['admin-products.html', '/admin/products'],
      ['admin-product-add.html', '/admin/products'],
      ['admin-reports.html', '/admin/reports'],
      ['admin-account-recovery.html', '/admin/login'],
      ['admin-forgot-password.php', '/admin/login'],
      ['admin-recovery.php', '/admin/login'],
      ['mfh-portal-auth.html', '/forgot-password'],
    ];

    // CQ-7: permanent: true for SEO-correct 301 redirects (old PHP/HTML URLs)
    return [
      {
        source: '/:path*',
        has: [{ type: 'host', value: 'mahalaxmifashionhub.com' }],
        destination: 'https://www.mahalaxmifashionhub.com/:path*',
        permanent: true,
      },
      ...legacy.map(([source, destination]) => ({
        source: `/${source}`,
        destination,
        permanent: true,
      })),
    ];
  },
};

module.exports = nextConfig;
