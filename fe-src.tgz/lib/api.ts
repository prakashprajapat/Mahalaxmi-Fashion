const API_BASE = process.env.NEXT_PUBLIC_API_URL
  ?? (typeof window === 'undefined' ? 'http://localhost:5000/api' : '/api');

async function request<T>(
  path: string,
  options?: RequestInit,
  token?: string
): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options?.headers as Record<string, string>),
  };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  // Server-side GET requests: use Next.js Data Cache (revalidate every 60s so newly-added
  // products/settings show up quickly on cached pages like the homepage).
  const isServer = typeof window === 'undefined';
  const isGet = !options?.method || options.method === 'GET';
  const cacheOpts: RequestInit = isServer && isGet ? { next: { revalidate: 60 } } as RequestInit : {};

  const res = await fetch(`${API_BASE}${path}`, { ...cacheOpts, ...options, headers });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: res.statusText || `Error ${res.status}` }));
    // Handle ASP.NET Core validation errors (have 'title'/'errors' but no 'message')
    const msg = err.message || err.title || (err.errors ? JSON.stringify(err.errors) : null) || `Request failed (${res.status})`;
    throw new Error(msg);
  }
  return res.json();
}

// ── Products ─────────────────────────────────────────────────────────────────
export const productsApi = {
  getAll: (params?: {
    category?: string;
    subcategory?: string;
    bestSeller?: boolean;
    page?: number;
    pageSize?: number;
  }) => {
    const qs = new URLSearchParams(
      Object.entries(params ?? {})
        .filter(([, v]) => v !== undefined)
        .map(([k, v]) => [k, String(v)])
    ).toString();
    return request<{ success: boolean; products: import('@/types').Product[]; total: number }>(
      `/products${qs ? '?' + qs : ''}`
    );
  },
  getById: (id: number) =>
    request<{ success: boolean; product: import('@/types').Product }>(`/products/${id}`),
  // Typo-tolerant fuzzy search (backend Levenshtein + synonyms). Covers the whole catalogue.
  search: (q: string, limit = 24) =>
    request<{ success: boolean; products: import('@/types').Product[]; total: number; query: string }>(
      `/products/search?q=${encodeURIComponent(q)}&limit=${limit}`
    ),
  nextSku: (token: string) =>
    request<{ sku: string }>('/products/next-sku', {}, token),
  bulkSave: (products: unknown[], token: string) =>
    request('/products', { method: 'POST', body: JSON.stringify({ products }) }, token),
  update: (id: number, data: unknown, token: string) =>
    request(`/products/${id}`, { method: 'PUT', body: JSON.stringify(data) }, token),
  // Lightweight stock-only toggle (no need to resend the whole product)
  updateStock: (id: number, stock: string, token: string) =>
    request<{ success: boolean; product: import('@/types').Product }>(
      `/products/${id}/stock`, { method: 'PATCH', body: JSON.stringify({ stock }) }, token
    ),
  delete: (id: number, token: string) =>
    request(`/products/${id}`, { method: 'DELETE' }, token),
};

// ── Orders ───────────────────────────────────────────────────────────────────
export const ordersApi = {
  getAll: (params?: { customerId?: string; email?: string; phone?: string }, token?: string) => {
    const qs = new URLSearchParams(
      Object.entries(params ?? {}).filter(([, v]) => v).map(([k, v]) => [k, v!])
    ).toString();
    return request<{ success: boolean; orders: import('@/types').Order[] }>(
      `/orders${qs ? '?' + qs : ''}`,
      undefined,
      token
    );
  },
  getById: (id: string, token?: string) =>
    request<{ success: boolean; order: import('@/types').Order }>(`/orders/${id}`, undefined, token),
  // Delhivery pincode serviceability + COD + delivery-day estimate (public).
  checkPincode: (pin: string) =>
    request<{
      success: boolean; known: boolean; serviceable: boolean; cod: boolean;
      city?: string; state?: string; etaMinDays: number; etaMaxDays: number;
    }>(`/orders/pincode/${encodeURIComponent(pin)}`),
  // Live Delhivery tracking timeline (public, shipment-safe fields only).
  liveTrack: (awb: string) =>
    request<{
      success: boolean; live: boolean; orderId: string; siteStatus: string;
      courierStatus?: string; expectedDate?: string;
      scans?: Array<{ time: string; location: string; remark: string }>;
    }>(`/orders/live-track/${encodeURIComponent(awb)}`),
  place: (order: unknown, token?: string) =>
    request<{ success: boolean; orderId: string }>('/orders', {
      method: 'POST',
      body: JSON.stringify(order),
    }, token),
  cancel: (orderId: string, token: string) =>
    request<{ success: boolean; order: import('@/types').Order }>(
      `/orders/${orderId}/cancel`, { method: 'PATCH' }, token
    ),
  // Admin-only: permanently delete an order (used to clear test orders).
  deleteOrder: (orderId: string, token: string) =>
    request<{ success: boolean; orderId: string }>(
      `/orders/${orderId}`, { method: 'DELETE' }, token
    ),

  // Admin-only: fraud/risk analysis — pincode-wise order/cancel/return stats,
  // the high-risk customer "red zone", and the current COD-blocked pincodes.
  riskSummary: (token: string) =>
    request<{
      success: boolean;
      highRiskThreshold: number;
      codBlocked: string[];
      pincodes: Array<{
        pincode: string; city?: string | null; state?: string | null;
        total: number; cod: number; cancelled: number; returned: number; delivered: number;
        cancelRate: number; returnRate: number; risky: boolean; codBlocked: boolean;
      }>;
      riskyCustomers: Array<{
        customerId: string; name?: string | null; phone?: string | null;
        total: number; cancelled: number; returned: number;
      }>;
    }>('/orders/risk/summary', undefined, token),

  // Admin-only: turn Cash-on-Delivery on/off for a single pincode.
  setCodBlock: (pincode: string, blocked: boolean, token: string) =>
    request<{ success: boolean; codBlocked: string[] }>(
      '/orders/risk/cod-block',
      { method: 'POST', body: JSON.stringify({ pincode, blocked }) },
      token
    ),

  // Open the customer invoice (HTML) in a new tab. JWT can't ride a plain link, so we
  // fetch with the auth header then render from a blob URL. Backend enforces 12-month expiry.
  downloadInvoice: async (orderId: string, token: string) => {
    const res = await fetch(`${API_BASE}/orders/${orderId}/invoice`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    if (!res.ok) throw new Error(`invoice ${res.status}`);
    const html = await res.text();
    const url = URL.createObjectURL(new Blob([html], { type: 'text/html' }));
    window.open(url, '_blank');
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  },
  // Auto-generate a forward Delhivery AWB for an order.
  generateAwb: (orderId: string, token: string) =>
    request<{ success: boolean; awb?: string; order?: import('@/types').Order; message?: string }>(
      `/orders/${orderId}/generate-awb`, { method: 'POST' }, token
    ),
  requestReturn: (orderId: string, details: { issue?: string; invoiceNumber?: string; awb?: string; paymentMethod?: string; description?: string; callback?: string; openingVideo?: string; closingVideo?: string; openingPhotos?: string[]; closingPhotos?: string[] } | string, token: string) =>
    request<{ success: boolean; order: import('@/types').Order }>(
      `/orders/${orderId}/return`,
      { method: 'POST', body: JSON.stringify(typeof details === 'string' ? { reason: details } : { reason: details.description, ...details }) },
      token
    ),
  // Upload ONE return photo/video (called per file). kind ∈ openingVideo|closingVideo|openingPhoto|closingPhoto
  uploadReturnMedia: async (orderId: string, file: File, kind: string, token: string) => {
    const fd = new FormData();
    fd.append('file', file);
    fd.append('kind', kind);
    const res = await fetch(`${API_BASE}/orders/${orderId}/return-media`, {
      method: 'POST',
      headers: token ? { Authorization: `Bearer ${token}` } : undefined,
      body: fd,
    });
    if (!res.ok) {
      const e = await res.json().catch(() => ({ message: res.statusText }));
      throw new Error(e.message || `Upload failed (${res.status})`);
    }
    return res.json() as Promise<{ success: boolean; url: string }>;
  },
  // BUG-1: getByCustomer removed — /orders/my endpoint does not exist on backend
  // Use getAll({ email }) or getAll({ phone }) instead
  updateStatus: (data: { orderId: string; status: string; awb?: string; courier?: string }, token: string) =>
    request<{ success: boolean; order: import('@/types').Order }>(
      '/orders/status', { method: 'PATCH', body: JSON.stringify(data) }, token
    ),
  // Admin: approve (media deleted now) or reject (media kept 30 days, reason required) a return
  returnDecision: (orderId: string, decision: 'approve' | 'reject', reason: string, token: string) =>
    request<{ success: boolean; order: import('@/types').Order }>(
      `/orders/${orderId}/return-decision`,
      { method: 'POST', body: JSON.stringify({ decision, reason }) },
      token
    ),
  // Admin: assign a reverse-pickup AWB. mode 'manual' (paste AWB) or 'auto' (Delhivery generates it).
  assignReturnAwb: (orderId: string, data: { mode: 'manual' | 'auto'; awb?: string; courier?: string }, token: string) =>
    request<{ success: boolean; order: import('@/types').Order; awb: string; courier: string }>(
      `/orders/${orderId}/return-awb`,
      { method: 'POST', body: JSON.stringify(data) },
      token
    ),
};

// ── Customers ────────────────────────────────────────────────────────────────
export const customersApi = {
  // Bulk-campaign phone export (admin) — de-duplicated 10-digit mobiles.
  phones: (optedInOnly: boolean, token: string) =>
    request<{ success: boolean; phones: string[]; count: number; totalCustomers: number; optedIn: number }>(
      `/customers/phones?optedInOnly=${optedInOnly}`, undefined, token
    ),
  // Send a bulk promotional SMS campaign via MSG91 (fully server-side).
  sendCampaign: (data: { templateId: string; optedInOnly: boolean; vars?: Record<string, string> }, token: string) =>
    request<{ success: boolean; sent: number; failed: number; total: number; message: string }>(
      '/customers/campaign', { method: 'POST', body: JSON.stringify(data) }, token
    ),
  // token is passed when an ADMIN creates a customer from the panel (bypasses OTP).
  register: (data: unknown, token?: string) =>
    request<{ success: boolean; token: string; customer: import('@/types').Customer }>(
      '/customers/register', { method: 'POST', body: JSON.stringify(data) }, token
    ),
  login: (data: { email: string; password: string }) =>
    request<{ success: boolean; token: string; customer: import('@/types').Customer }>(
      '/customers/login', { method: 'POST', body: JSON.stringify(data) }
    ),
  sendOtp: (phone: string, purpose = 'login') =>
    request('/customers/send-otp', {
      method: 'POST',
      body: JSON.stringify({ phone, purpose }),
    }),
  sendEmailOtp: (email: string, purpose = 'login') =>
    request('/customers/send-otp', {
      method: 'POST',
      body: JSON.stringify({ email, purpose }),
    }),
  verifyOtp: (phone: string, otp: string) =>
    request<{ success: boolean; token?: string; customer?: import('@/types').Customer; newUser?: boolean }>(
      '/customers/verify-otp', { method: 'POST', body: JSON.stringify({ phone, otp }) }
    ),
  forgotPasswordSendOtp: (identifier: string) =>
    request<{ success: boolean; sentTo?: { email?: string | null; phone?: string | null }; devOtp?: string }>(
      '/customers/forgot-password/send-otp',
      { method: 'POST', body: JSON.stringify({ identifier }) }
    ),
  resetPassword: (data: { email: string; otp: string; password: string }) =>
    request('/customers/reset-password', { method: 'POST', body: JSON.stringify(data) }),
  updateProfile: (id: number, data: unknown, token: string) =>
    request<{ success: boolean; customer: import('@/types').Customer }>(
      `/customers/${id}`, { method: 'PUT', body: JSON.stringify(data) }, token
    ),
  // Upload the customer's profile photo (multipart). Returns the updated customer.
  uploadPhoto: async (id: number, file: File, token: string) => {
    const fd = new FormData();
    fd.append('file', file);
    const res = await fetch(`${API_BASE}/customers/${id}/photo`, {
      method: 'POST',
      headers: token ? { Authorization: `Bearer ${token}` } : undefined,
      body: fd,
    });
    if (!res.ok) {
      const e = await res.json().catch(() => ({ message: res.statusText }));
      throw new Error(e.message || `Upload failed (${res.status})`);
    }
    return res.json() as Promise<{ success: boolean; customer: import('@/types').Customer }>;
  },
  deactivate: (id: number, reason: string, token: string) =>
    request<{ success: boolean; customer: import('@/types').Customer }>(
      `/customers/${id}/deactivate`, { method: 'PATCH', body: JSON.stringify({ reason }) }, token
    ),
  delete: (id: number, token: string) =>
    request(`/customers/${id}`, { method: 'DELETE' }, token),
  getAll: (token: string, params?: { search?: string; page?: number; pageSize?: number }) => {
    const qs = new URLSearchParams(
      Object.entries(params ?? {}).filter(([, v]) => v !== undefined).map(([k, v]) => [k, String(v)])
    ).toString();
    return request<{ success: boolean; customers: import('@/types').Customer[]; total: number }>(
      `/customers${qs ? '?' + qs : ''}`, undefined, token
    );
  },
};

// ── Auth ─────────────────────────────────────────────────────────────────────
export const authApi = {
  adminLogin: (email: string, password: string) =>
    request<{ success: boolean; token: string }>('/auth/admin-login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),
  changeAdminPassword: (newPassword: string, token: string) =>
    request<{ success: boolean }>('/auth/admin-change-password', {
      method: 'POST',
      body: JSON.stringify({ newPassword }),
    }, token),
  me: (token: string) => request<{ success: boolean; email: string; role: string }>('/auth/me', undefined, token),
};

// ── Settings ─────────────────────────────────────────────────────────────────
// Client-side settings cache: layout, navbar, footer, offer banner, whatsapp float, etc. all
// request /settings on the same page load. We dedupe those into ONE network call and reuse the
// result briefly, instead of firing 6+ identical requests. (Server rendering keeps using Next's
// own per-request data cache.) Any admin save clears the cache so changes show on the next load.
type SettingsResp = { success: boolean; settings: Record<string, string> };
let _settingsCache: { at: number; data: SettingsResp } | null = null;
let _settingsInflight: Promise<SettingsResp> | null = null;
const SETTINGS_TTL = 30_000;

// The quality gate seen from the admin: which products are fit for the website
// and which are not. The sweep that acts on it runs by itself every hour; the
// endpoint below just runs it now instead of waiting.
export interface QualityIssue { field: string; message: string }
export interface QualityRow {
  id: number;
  name: string;
  sku?: string;
  category: string;
  subcategory: string;
  status: string;
  live: boolean;
  passed: boolean;
  wouldGoToDraft: boolean;
  errors: QualityIssue[];
  warnings: QualityIssue[];
}
/** What the hourly sweep did the last time it ran. Absent until it has run once. */
export interface QualitySweep {
  ranAt: string;
  checkedCount: number;
  takenDown: number;
  putBack: number;
  takenDownNames: string[];
  putBackNames: string[];
}
export interface QualityReport {
  success: boolean;
  total: number;
  live: number;
  passing: number;
  failing: number;
  wouldGoToDraft: number;
  /** Drafts that now pass — the sweep will put these back on the website on its own. */
  wouldGoLive: number;
  byReason: { field: string; count: number }[];
  lastSweep?: QualitySweep | null;
  products: QualityRow[];
}

export const productQualityApi = {
  report: (token: string): Promise<QualityReport> =>
    request<QualityReport>('/product-quality', {}, token),

  /** Runs the hourly sweep now rather than waiting for it. Both directions. */
  enforce: (token: string) =>
    request<{
      success: boolean;
      movedToDraft: number;
      putBackOnWebsite: number;
      checkedCount: number;
      takenDownNames: string[];
      putBackNames: string[];
    }>('/product-quality/enforce', { method: 'POST' }, token),
};

// The SEO writing the owner edits from the admin panel: blog articles, keyword
// collection pages and the category copy. Reading is public — it is what the
// website shows. Writing needs the Settings permission, checked by the backend.
export const seoContentApi = {
  get: (): Promise<{
    success: boolean;
    blog: any[];
    collections: any[];
    categories: Record<string, any>;
    homeTiles: any[];
  }> => request('/seo-content'),

  saveBlog: (posts: unknown[], token: string) =>
    request('/seo-content/blog', { method: 'PUT', body: JSON.stringify(posts) }, token),

  saveCollections: (items: unknown[], token: string) =>
    request('/seo-content/collections', { method: 'PUT', body: JSON.stringify(items) }, token),

  saveCategories: (cats: Record<string, unknown>, token: string) =>
    request('/seo-content/categories', { method: 'PUT', body: JSON.stringify(cats) }, token),

  saveHomeTiles: (tiles: unknown[], token: string) =>
    request('/seo-content/home-tiles', { method: 'PUT', body: JSON.stringify(tiles) }, token),

  /** Clear the page caches so an edit is live immediately instead of within the minute. */
  publish: async (token: string) => {
    try {
      await fetch('/admin/seo/revalidate', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
    } catch {
      // The save already succeeded; the pages will catch up on their own.
    }
  },
};

export const settingsApi = {
  getAll: (): Promise<SettingsResp> => {
    if (typeof window === 'undefined')
      return request<SettingsResp>('/settings');            // server: use Next data cache
    const now = Date.now();
    if (_settingsCache && now - _settingsCache.at < SETTINGS_TTL)
      return Promise.resolve(_settingsCache.data);          // fresh enough — reuse
    if (_settingsInflight) return _settingsInflight;        // a request is already in flight — join it
    _settingsInflight = request<SettingsResp>('/settings')
      .then(data => { _settingsCache = { at: Date.now(), data }; return data; })
      .finally(() => { _settingsInflight = null; });
    return _settingsInflight;
  },
  // Everything, secrets included — admin only. The public getAll above hides
  // anything credential-shaped, so the Settings screen uses this one instead or
  // the owner would be typing into boxes that always look empty.
  getAllAdmin: (token: string): Promise<SettingsResp> =>
    request<SettingsResp>('/settings/admin', {}, token),
  upsert: (key: string, value: string, token: string) => {
    _settingsCache = null;                                  // invalidate so the change shows up
    return request(`/settings/${key}`, { method: 'PUT', body: JSON.stringify({ value }) }, token);
  },
  bulkUpsert: (settings: Record<string, string>, token: string) => {
    _settingsCache = null;                                  // invalidate so the change shows up
    return request('/settings/bulk', { method: 'POST', body: JSON.stringify(settings) }, token);
  },
  // Upload a site image (hero photos etc.) — admin only; returns its URL.
  uploadImage: async (file: File, token: string): Promise<string> => {
    const fd = new FormData();
    fd.append('file', file);
    const res = await fetch(`${API_BASE}/settings/upload-image`, {
      method: 'POST',
      headers: token ? { Authorization: `Bearer ${token}` } : undefined,
      body: fd,
    });
    if (!res.ok) {
      const e = await res.json().catch(() => ({ message: res.statusText }));
      throw new Error(e.message || `Upload failed (${res.status})`);
    }
    const j = await res.json();
    return j.url as string;
  },
};

// ── Payments ─────────────────────────────────────────────────────────────────
export const paymentsApi = {
  createOrder: (data: unknown) =>
    request<{ success: boolean; orderId: string; localOrderId: string; keyId: string; amountPaise: number }>(
      '/payments/create-order', { method: 'POST', body: JSON.stringify(data) }
    ),
  verify: (data: { razorpayOrderId: string; razorpayPaymentId: string; razorpaySignature: string }) =>
    request('/payments/verify', { method: 'POST', body: JSON.stringify(data) }),
  reconcile: (from: string, to: string, token: string) =>
    request<{
      success: boolean;
      summary: {
        totalPayments: number; matched: number; amountMismatch: number;
        paymentWithoutOrder: number; orderWithoutPayment: number;
        refunded: number; failed: number; capturedTotal: number; refundedTotal: number;
      };
      rows: ReconcileRow[];
    }>(`/payments/reconcile?from=${from}&to=${to}`, undefined, token),
};

// ── Cashfree (primary online gateway) ────────────────────────────────────────
export const cashfreeApi = {
  createOrder: (data: {
    amount: number; currency?: string; cart?: unknown; customer?: unknown; shipping?: unknown;
    customerId?: string; customerName?: string; customerEmail?: string; customerPhone?: string;
    walletUsed?: number; fullTotal?: number;
  }) =>
    request<{ success: boolean; setupRequired?: boolean; paymentSessionId: string; localOrderId: string; mode: string }>(
      '/cashfree/create-order', { method: 'POST', body: JSON.stringify(data) }
    ),
  verify: (localOrderId: string) =>
    request<{ success: boolean; verified: boolean; orderStatus: string; paymentId?: string | null }>(
      '/cashfree/verify', { method: 'POST', body: JSON.stringify({ localOrderId }) }
    ),
};

export interface ReconcileRow {
  category: 'MATCHED' | 'AMOUNT_MISMATCH' | 'PAYMENT_NO_ORDER' | 'ORDER_NO_PAYMENT';
  paymentId?: string | null;
  paymentAmount?: number | null;
  refundedAmount: number;
  paymentStatus?: string | null;
  paymentDate?: string | null;
  email: string;
  contact: string;
  orderId?: string | null;
  orderTotal?: number | null;
  orderStatus?: string | null;
}

// ── Coupons ───────────────────────────────────────────────────────────────────
export const couponsApi = {
  validate: (code: string, orderAmount: number, customerId?: number) =>
    request<{ success: boolean; code: string; type: string; value: number; discount: number; message: string }>(
      '/coupons/validate', { method: 'POST', body: JSON.stringify({ code, orderAmount, customerId }) }
    ),
  list: (token: string) =>
    request<unknown[]>('/coupons', undefined, token),
  create: (data: unknown, token: string) =>
    request<{ success: boolean; id: number }>('/coupons', { method: 'POST', body: JSON.stringify(data) }, token),
  update: (id: number, data: unknown, token: string) =>
    request('/coupons/' + id, { method: 'PUT', body: JSON.stringify(data) }, token),
  delete: (id: number, token: string) =>
    request('/coupons/' + id, { method: 'DELETE' }, token),
};

// ── Staff ─────────────────────────────────────────────────────────────────────
export const staffApi = {
  list: (token: string) =>
    request<Array<{ id: number; name: string; username: string; email?: string; role: string; permissions?: string; isActive: boolean; lastLogin?: string; createdAt?: string }>>(
      '/staff', undefined, token),
  create: (data: { name: string; username: string; email?: string; password: string; role: string; permissions?: string }, token: string) =>
    request<{ message: string; id: number }>('/staff', { method: 'POST', body: JSON.stringify(data) }, token),
  update: (id: number, data: { name?: string; role?: string; permissions?: string }, token: string) =>
    request<{ message: string }>('/staff/' + id, { method: 'PUT', body: JSON.stringify(data) }, token),
  remove: (id: number, token: string) =>
    request('/staff/' + id, { method: 'DELETE' }, token),
  resetPassword: (id: number, newPassword: string, token: string) =>
    request('/staff/' + id + '/reset-password', { method: 'PUT', body: JSON.stringify({ newPassword }) }, token),
  toggleActive: (id: number, token: string) =>
    request<{ isActive: boolean }>('/staff/' + id + '/toggle-active', { method: 'PUT' }, token),
};

// ── Suppliers ─────────────────────────────────────────────────────────────────
export const suppliersApi = {
  apply: (data: Record<string, string>) =>
    request<{ success: boolean; message: string }>(
      '/suppliers', { method: 'POST', body: JSON.stringify(data) }
    ),
};

// ── Reviews ───────────────────────────────────────────────────────────────────
export interface PublicReview {
  id: number;
  productId: number;
  productName: string | null;
  productImage: string | null;
  customerName: string;
  rating: number;
  text: string;
  imageUrls: string | null;
  createdAt: string;
}

export const reviewsApi = {
  getPending: (token: string) =>
    request<{ success: boolean; reviews: import('@/types').Review[] }>('/reviews/pending', undefined, token),
  getByProduct: (productId: number) =>
    request<{ success: boolean; reviews: import('@/types').Review[] }>(`/reviews/product/${productId}`),

  /** Approved reviews across the catalogue, newest first, plus how many there are in all. */
  recent: (take = 24) =>
    request<{ success: boolean; total: number; reviews: PublicReview[] }>(`/reviews/recent?take=${take}`),
  submit: (data: { productId: number; rating: number; text: string; orderId?: string; images?: string[] }, token: string) =>
    request<{ success: boolean }>('/reviews', { method: 'POST', body: JSON.stringify(data) }, token),
  // Upload ONE review photo (called per file); returns its URL to include in submit().
  uploadImage: async (file: File, token: string): Promise<string> => {
    const fd = new FormData();
    fd.append('file', file);
    const res = await fetch(`${API_BASE}/reviews/upload`, {
      method: 'POST',
      headers: token ? { Authorization: `Bearer ${token}` } : undefined,
      body: fd,
    });
    if (!res.ok) {
      const e = await res.json().catch(() => ({ message: res.statusText }));
      throw new Error(e.message || `Upload failed (${res.status})`);
    }
    const j = await res.json();
    return j.url as string;
  },
  approve: (id: number, token: string) =>
    request(`/reviews/${id}/approve`, { method: 'PATCH' }, token),
  reject: (id: number, token: string) =>
    request(`/reviews/${id}/reject`, { method: 'PATCH' }, token),
  delete: (id: number, token: string) =>
    request(`/reviews/${id}`, { method: 'DELETE' }, token),
};

// ── Wishlist (server-synced for logged-in customers) ──────────────────────────
export const wishlistApi = {
  list: (token: string) =>
    request<{ success: boolean; products: import('@/types').Product[] }>('/wishlist', undefined, token),
  add: (productId: number, token: string) =>
    request<{ success: boolean }>(`/wishlist/${productId}`, { method: 'POST' }, token),
  remove: (productId: number, token: string) =>
    request<{ success: boolean }>(`/wishlist/${productId}`, { method: 'DELETE' }, token),
  // Union guest (localStorage) ids into the account, then return the merged list. Called on login.
  merge: (productIds: number[], token: string) =>
    request<{ success: boolean; products: import('@/types').Product[] }>(
      '/wishlist/merge', { method: 'POST', body: JSON.stringify({ productIds }) }, token
    ),
};

// ── Saved delivery addresses (address book) ───────────────────────────────────
export interface SavedAddress {
  id: number;
  label: string;
  fullName: string;
  phone: string;
  addrLine1: string;
  addrLine2: string;
  pincode: string;
  city: string;
  state: string;
  isDefault: boolean;
}

export type AddressInput = Omit<SavedAddress, 'id' | 'isDefault'> & { isDefault?: boolean };

export const addressesApi = {
  list: (token: string) =>
    request<{ success: boolean; addresses: SavedAddress[] }>('/addresses', undefined, token),
  create: (data: AddressInput, token: string) =>
    request<{ success: boolean; address: SavedAddress }>('/addresses', { method: 'POST', body: JSON.stringify(data) }, token),
  update: (id: number, data: AddressInput, token: string) =>
    request<{ success: boolean; address: SavedAddress }>(`/addresses/${id}`, { method: 'PUT', body: JSON.stringify(data) }, token),
  remove: (id: number, token: string) =>
    request<{ success: boolean }>(`/addresses/${id}`, { method: 'DELETE' }, token),
  setDefault: (id: number, token: string) =>
    request<{ success: boolean }>(`/addresses/${id}/default`, { method: 'POST' }, token),
};

// ── Loyalty Wallet ────────────────────────────────────────────────────────────
export interface WalletTxn {
  id: number;
  amount: number;
  type: string;
  orderId: string | null;
  note: string | null;
  balanceAfter: number;
  createdAt: string;
}
export const walletApi = {
  // The signed-in customer's own wallet.
  mine: (token: string) =>
    request<{ success: boolean; balance: number; transactions: WalletTxn[] }>('/wallet', undefined, token),
  // Admin: any customer's wallet.
  forCustomer: (customerId: number, token: string) =>
    request<{ success: boolean; balance: number; transactions: WalletTxn[] }>(`/wallet/customer/${customerId}`, undefined, token),
  // Admin: credit (+) or debit (-) a customer's wallet.
  adjust: (data: { customerId: number; amount: number; note?: string }, token: string) =>
    request<{ success: boolean; balance: number }>('/wallet/adjust', { method: 'POST', body: JSON.stringify(data) }, token),
  // Customer: credit wallet after a verified "add money" payment.
  topup: (localOrderId: string, token: string) =>
    request<{ success: boolean; balance: number; already?: boolean }>('/wallet/topup', { method: 'POST', body: JSON.stringify({ localOrderId }) }, token),
};

// ── Refer & Earn ──────────────────────────────────────────────────────────────
export const referralApi = {
  mine: (token: string) =>
    request<{ success: boolean; enabled: boolean; code: string; discount: number; minOrder: number; reward: number; friendsJoined: number; totalEarned: number }>(
      '/referral/me', undefined, token
    ),
};
