import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { productsApi } from '@/lib/api';
import { COLLECTION_SLUGS, matchesCollection } from '@/lib/collections';
import { getCollections } from '@/lib/seoContent';
import CategoryPageContent from '@/components/product/CategoryPageContent';
import { productSlug } from '@/lib/productSlug';
import { toListingProducts } from '@/lib/listingProduct';

// JSON.stringify leaves "<" alone, so a name holding "</script>" would close
// this tag early and run as script. Escaped, the JSON stays valid either way.
function safeJsonLd(value: unknown): string {
  return JSON.stringify(value).replace(/</g, '\\u003c');
}

// SEO landing pages: /collections/cotton-nighty, /collections/nighty-under-500 …
// Each has its own title/description/H1/intro/FAQ, and the products filter
// themselves — a new product joins the right collections on its own.
//
// The definitions come from getCollections(), which is the code file plus
// whatever the owner has since edited in Admin → Collection Pages.

export const revalidate = 300;

// Only the built-in slugs are pre-rendered. A collection the owner creates in
// the admin renders on first visit instead — which is right, because the list
// of them is not known at build time, and the API may not even be reachable
// while the build runs.
export function generateStaticParams() {
  return COLLECTION_SLUGS.map(slug => ({ slug }));
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const def = (await getCollections())[params.slug];
  if (!def) return {};

    // An empty page is not worth indexing, and a shop that ships empty pages
    // to Google teaches it to trust the rest of the domain less. This is
    // decided per request from the live catalogue, so the page comes back
    // into the index by itself the day it has stock — nothing to remember,
    // nothing to undo.
  const { products } = await productsApi
    .getAll({ subcategory: def.subcategory, pageSize: 500 })
    .catch(() => ({ products: [] as any[] }));
  const isEmpty = (products as any[]).filter(p => matchesCollection(p, def)).length === 0;

  return {
    title: { absolute: def.title },
    description: def.description,
    alternates: { canonical: `/collections/${def.slug}` },
    openGraph: { title: def.title, description: def.description },
    ...(isEmpty ? { robots: { index: false, follow: true } } : {}),
  };
}

export default async function CollectionPage({ params }: { params: { slug: string } }) {
  const slug = params.slug;
  const all = await getCollections();
  const def = all[slug];
  if (!def) notFound();

  const { products } = await productsApi
    .getAll({ subcategory: def.subcategory, pageSize: 500 })
    .catch(() => ({ products: [] as any[] }));
  const matched = (products as any[]).filter(p => matchesCollection(p, def));

  const faqJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: def.faqs.map(f => ({
      '@type': 'Question',
      name: f.q,
      acceptedAnswer: { '@type': 'Answer', text: f.a },
    })),
  };
  const breadcrumbJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://www.mahalaxmifashionhub.com' },
      { '@type': 'ListItem', position: 2, name: 'Collections', item: 'https://www.mahalaxmifashionhub.com/products' },
      { '@type': 'ListItem', position: 3, name: def.label },
    ],
  };
  // ItemList of the products on this collection page — helps Google surface the list.
  const itemListJsonLd = matched.length > 0 ? {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    name: def.h1,
    numberOfItems: matched.length,
    itemListElement: (matched as any[]).slice(0, 30).map((p, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      url: `https://www.mahalaxmifashionhub.com/products/${productSlug(p.name, p.dbId)}`,
      name: p.name,
    })),
  } : null;

  // Cross-links (Koskii-style internal linking) — same category first, phir baaki
  const others = Object.keys(all)
    .filter(s => s !== slug)
    .sort((a, b) => (all[b].subcategory === def.subcategory ? 1 : 0) - (all[a].subcategory === def.subcategory ? 1 : 0));

  return (
    <>
      <section className="page-hero">
        <p className="eyebrow">{def.eyebrow}</p>
        <h1>{def.h1}</h1>
        <p>{def.sub}</p>
      </section>

      {matched.length > 0 ? (
        <CategoryPageContent products={toListingProducts(matched as any[]) as any} category={def.label} icon="🛍️" desc={def.sub} allHref="/products" />
      ) : (
        <section style={{ textAlign: 'center', padding: '3rem 1.5rem' }}>
          <p style={{ color: '#777' }}>New products are being added to this collection soon.</p>
          <Link href="/products" className="button primary" style={{ display: 'inline-block', marginTop: '1rem' }}>
            Browse all products →
          </Link>
        </section>
      )}

      {/* SEO copy + FAQ (FAQPage rich-result eligible) */}
      <section style={{ background: '#fafafa', borderTop: '1px solid #eee', padding: '2rem 1.5rem' }}>
        <div style={{ maxWidth: '900px', margin: '0 auto' }}>
          <h2 style={{ fontSize: '1.25rem', fontWeight: 800, color: '#4a1f27', margin: '0 0 .9rem' }}>{def.h1} — Mahalaxmi Fashion Hub</h2>
          {def.intro.map((p, i) => (
            <p key={i} style={{ color: '#555', fontSize: '.92rem', lineHeight: 1.65, margin: '0 0 .8rem' }}>{p}</p>
          ))}

          <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: '#1a1a1a', margin: '1.4rem 0 .6rem' }}>Frequently Asked Questions</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '.5rem' }}>
            {def.faqs.map((f, i) => (
              <details key={i} style={{ background: '#fff', border: '1px solid #eee', borderRadius: '10px', padding: '.75rem 1rem' }}>
                <summary style={{ cursor: 'pointer', fontWeight: 600, color: '#1a1a1a', fontSize: '.92rem' }}>{f.q}</summary>
                <p style={{ color: '#555', fontSize: '.88rem', lineHeight: 1.6, margin: '.6rem 0 0' }}>{f.a}</p>
              </details>
            ))}
          </div>

          {/* Internal links — Koskii-style collection cross-linking */}
          <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: '#1a1a1a', margin: '1.6rem 0 .6rem' }}>Explore More Collections</h3>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '.5rem' }}>
            {others.map(s => (
              <Link key={s} href={`/collections/${s}`}
                style={{ background: '#fff', border: '1px solid #e6dcdc', borderRadius: '999px', padding: '.4rem .95rem', fontSize: '.85rem', fontWeight: 600, color: '#722f37', textDecoration: 'none' }}>
                {all[s].label}
              </Link>
            ))}
          </div>
        </div>
      </section>

      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: safeJsonLd(faqJsonLd) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: safeJsonLd(breadcrumbJsonLd) }} />
      {itemListJsonLd && (
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: safeJsonLd(itemListJsonLd) }} />
      )}
    </>
  );
}
