'use client';
import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { getCart, cartTotal, clearCart, cartShipping, finalUnitPrice, unitBase, updateQuantity, removeFromCart } from '@/lib/cart';
import { productImageSrc } from '@/lib/productImages';
import PincodeChecker from '@/components/checkout/PincodeChecker';
import { getCustomer, getToken } from '@/lib/auth';
import { storage } from '@/lib/safeStorage';
import { ordersApi, paymentsApi, cashfreeApi, couponsApi, settingsApi, walletApi, addressesApi } from '@/lib/api';
import type { SavedAddress } from '@/lib/api';
import Link from 'next/link';
import { trackEvent, toGa4Items, trackAdsConversion, getGaClientId } from '@/lib/analytics';
import type { CartItem, Customer } from '@/types';

// Map cart items → GA4 ecommerce items.
const cartToItems = (lines: CartItem[]) =>
  toGa4Items(lines.map(i => ({
    dbId: i.dbId, sku: (i as any).sku, name: i.name,
    category: (i as any).category, quantity: i.quantity, price: finalUnitPrice(i),
  })));

function getPincodeState(pincode: string): string {
  if (pincode.length < 2) return '';
  const prefix = parseInt(pincode.substring(0, 2), 10);
  if (prefix === 11) return 'Delhi';
  if (prefix >= 12 && prefix <= 13) return 'Haryana';
  if (prefix >= 14 && prefix <= 16) return 'Punjab';
  if (prefix === 17) return 'Himachal Pradesh';
  if (prefix >= 18 && prefix <= 19) return 'Jammu & Kashmir';
  if (prefix >= 20 && prefix <= 28) return 'Uttar Pradesh';
  if (prefix >= 30 && prefix <= 34) return 'Rajasthan';
  if (prefix >= 36 && prefix <= 39) return 'Gujarat';
  if (prefix >= 40 && prefix <= 44) return 'Maharashtra';
  if (prefix >= 45 && prefix <= 49) return 'Madhya Pradesh';
  if (prefix >= 50 && prefix <= 53) return 'Telangana';
  if (prefix >= 56 && prefix <= 59) return 'Karnataka';
  if (prefix >= 60 && prefix <= 64) return 'Tamil Nadu';
  if (prefix >= 67 && prefix <= 69) return 'Kerala';
  if (prefix >= 70 && prefix <= 74) return 'West Bengal';
  if (prefix >= 75 && prefix <= 77) return 'Odisha';
  if (prefix === 78) return 'Assam';
  if (prefix === 79) return 'Arunachal Pradesh';
  if (prefix >= 80 && prefix <= 85) return 'Bihar';
  if (prefix >= 90 && prefix <= 97) return 'Jharkhand';
  return '';
}

type Step = 'shipping' | 'payment' | 'confirm';

// Flat handling fee added when the customer chooses Cash on Delivery.
const COD_FEE = 50;

// Robustly load an external SDK <script> and wait until its global is ready.
// (Fixes "window.Cashfree is not a function": React-rendered <script async> can execute
//  late or not at all; we load it on demand at payment time instead.)
function loadScriptOnce(src: string): Promise<void> {
  return new Promise((resolve, reject) => {
    if (typeof document === 'undefined') { resolve(); return; }
    if (document.querySelector(`script[data-dyn="${src}"]`)) { resolve(); return; }
    const el = document.createElement('script');
    el.src = src; el.async = true; el.dataset.dyn = src;
    el.onload = () => resolve();
    el.onerror = () => reject(new Error('sdk-load-failed'));
    document.head.appendChild(el);
  });
}
async function ensureCashfreeSdk(): Promise<void> {
  if (typeof (window as any).Cashfree === 'function') return;
  try { await loadScriptOnce('https://sdk.cashfree.com/js/v3/cashfree.js'); } catch {}
  for (let i = 0; i < 60 && typeof (window as any).Cashfree !== 'function'; i++) {
    await new Promise(r => setTimeout(r, 100));
  }
  if (typeof (window as any).Cashfree !== 'function') {
    throw new Error('Payment gateway could not load. Please check your internet connection and try again.');
  }
}

export default function CheckoutPage() {
  const router = useRouter();
  const [cart, setCart] = useState<CartItem[]>([]);
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [step, setStep] = useState<Step>('shipping');
  const [loading, setLoading] = useState(false);
  const [orderId, setOrderId] = useState('');
  const [honeypot, setHoneypot] = useState('');
  const [payMethod, setPayMethod] = useState<'online' | 'cod'>('online');
  const [codConfirm, setCodConfirm] = useState(false); // "Confirm Cash on Delivery Order" popup
  // Cash on Delivery money rules come from admin Settings; the server enforces the same
  // numbers, so these are only for what the shopper sees.
  const [codFeeAmt, setCodFeeAmt] = useState(COD_FEE);
  const [codAdvanceAmt, setCodAdvanceAmt] = useState(0);
  const [codAvailable, setCodAvailable] = useState(true); // COD allowed for the entered pincode?

  const [shipping, setShipping] = useState({
    name: '', email: '', phone: '', address: '', city: '', pincode: '', state: '',
  });

  const [panData, setPanData] = useState({ panNumber: '', panName: '' });

  // Saved address book. Picking a card fills the shipping form below, so the
  // shopper never retypes an address they have already given us.
  const [savedAddresses, setSavedAddresses] = useState<SavedAddress[]>([]);
  const [pickedAddressId, setPickedAddressId] = useState<number | null>(null);

  const applyAddress = (a: SavedAddress) => {
    setPickedAddressId(a.id);
    setShipping(s => ({
      ...s,
      name: a.fullName || s.name,
      phone: a.phone || s.phone,
      address: [a.addrLine1, a.addrLine2].filter(Boolean).join(', '),
      pincode: a.pincode || s.pincode,
      city: a.city || s.city,
      state: a.state || s.state,
    }));
  };

  useEffect(() => {
    const token = getToken();
    if (!token) return;
    let cancelled = false;
    addressesApi.list(token)
      .then(r => {
        if (cancelled || !r?.addresses?.length) return;
        setSavedAddresses(r.addresses);
        const preferred = r.addresses.find(a => a.isDefault) ?? r.addresses[0];
        if (preferred) applyAddress(preferred);
      })
      .catch(() => { /* address book is optional — the form still works */ });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [couponCode, setCouponCode] = useState('');
  const [couponApplied, setCouponApplied] = useState<{ code: string; discount: number; message: string } | null>(null);
  const [couponError, setCouponError] = useState('');
  const [couponLoading, setCouponLoading] = useState(false);

  // Loyalty wallet
  const [walletBalance, setWalletBalance] = useState(0);
  const [walletRedeemPct, setWalletRedeemPct] = useState(20);
  const [walletEnabled, setWalletEnabled] = useState(true);
  const [useWallet, setUseWallet] = useState(false);

  const applyCustomer = (cust: Customer) => {
    setCustomer(cust);
    setShipping(s => ({
      ...s,
      name: `${cust.firstName} ${cust.lastName}`.trim(),
      email: cust.email ?? '',
      phone: cust.phone,
      address: [cust.addrLine1, cust.addrLine2].filter(Boolean).join(', '),
      city: cust.district,
      pincode: cust.pincode,
      state: cust.state,
    }));
  };

  useEffect(() => {
    // The signed-in shopper is loaded on EVERY visit to this page, including the
    // return from Cashfree. It used to happen only on a normal visit, below the
    // cf_order branch, so a customer coming back from the gateway was shown
    // "Login to auto-fill shipping details" while already logged in.
    const cust = getCustomer();
    if (cust) applyCustomer(cust);
    const onAuth = () => {
      const next = getCustomer();
      if (next) applyCustomer(next);
    };
    window.addEventListener('auth-changed', onAuth);
    const cleanup = () => window.removeEventListener('auth-changed', onAuth);

    // Cashfree full-page redirect return: verify payment, show success, skip the empty-cart bounce.
    const cfOrder = typeof window !== 'undefined' ? new URLSearchParams(window.location.search).get('cf_order') : null;
    if (cfOrder) {
      setLoading(true);
      cashfreeApi.verify(cfOrder).then(async v => {
        if (v.verified) {
          // Cash on Delivery advance: the order was deliberately NOT placed before the
          // payment, so place it now that the advance is confirmed. An abandoned payment
          // therefore leaves no order behind.
          let pending: any = null;
          try {
            const raw = sessionStorage.getItem('mfh-pending-cod');
            pending = raw ? JSON.parse(raw) : null;
          } catch { /* private mode */ }
          if (pending?.id === cfOrder && pending.payload) {
            try {
              await ordersApi.place(pending.payload, getToken() ?? undefined);
            } catch (e) {
              alert('Your advance payment went through, but we could not place the order automatically. Please contact us on WhatsApp with this reference: ' + cfOrder + ' — do NOT pay again.');
              return;
            } finally {
              try { sessionStorage.removeItem('mfh-pending-cod'); } catch {}
            }
          }
          clearCart(); setOrderId(cfOrder); setStep('confirm');
        }
        else {
          // Cashfree's own status tells us whether money could possibly have moved.
          // ACTIVE = the customer left the gateway without paying; EXPIRED /
          // TERMINATED = the attempt was closed unpaid. In all of those nothing was
          // charged and there is nothing for the shopper to chase — showing an
          // MFH… reference there just looks like an order number and worries them.
          const st = (v.orderStatus ?? '').toUpperCase();
          const nothingCharged = st === 'ACTIVE' || st === 'EXPIRED'
            || st === 'TERMINATED' || st === 'TERMINATION_REQUESTED';
          alert(nothingCharged
            ? 'Payment was not completed, so no order was placed and nothing was charged. Your cart is saved — you can try again.'
            : 'Your payment could not be confirmed and no order has been created. If any amount was deducted it will be refunded automatically — please do not pay again. If you need help, contact us on WhatsApp and quote this payment reference: ' + cfOrder + '.');
          router.push('/cart');
        }
      }).catch(() => alert('We could not reach the payment gateway to confirm your payment, so no order has been created — please do not pay again. If any amount was deducted, contact us on WhatsApp and quote this payment reference: ' + cfOrder + '.'))
      .finally(() => { setLoading(false); try { window.history.replaceState({}, '', '/checkout'); } catch {} });
      return cleanup;
    }
    const c = getCart();
    if (c.length === 0) { router.push('/cart'); return cleanup; }
    setCart(c);
    // GA4: user has reached checkout with items in the cart.
    trackEvent('begin_checkout', { currency: 'INR', value: cartTotal(c), items: cartToItems(c) });
    // Pre-fill PAN from localStorage
    try {
      const saved = storage.json<any>('mfh-pan', {});
      if (saved.panNumber) setPanData({ panNumber: saved.panNumber, panName: saved.panName ?? '' });
    } catch {}
    return cleanup;
  }, [router]);

  // Load loyalty settings + the signed-in customer's wallet balance.
  useEffect(() => {
    settingsApi.getAll().then(r => {
      const s = r.settings ?? {};
      setWalletEnabled((s.loyaltyEnabled ?? 'true') !== 'false');
      const fee = parseFloat(s.codFeeAmount ?? '');
      if (!Number.isNaN(fee) && fee >= 0) setCodFeeAmt(fee);
      const adv = parseFloat(s.codAdvanceAmount ?? '');
      if (!Number.isNaN(adv) && adv >= 0) setCodAdvanceAmt(adv);
      const p = parseFloat(s.loyaltyRedeemMaxPercent ?? '20');
      if (p > 0) setWalletRedeemPct(p);
    }).catch(() => {});
    const token = getToken();
    if (token) walletApi.mine(token).then(r => setWalletBalance(r.balance || 0)).catch(() => setWalletBalance(0));
    else setWalletBalance(0);
  }, [customer]);

  // Local Balotra delivery = free shipping. Shipping is normally baked into each item's
  // price; for a Balotra post office / pincode we drop it so the customer pays the base rate.
  const isBalotra = /balotra/i.test(shipping.city || '') || (shipping.pincode || '').trim() === '344022';
  const shipWaiver = isBalotra ? cartShipping(cart) : 0;
  // Per-item price actually charged (base for Balotra, base + shipping otherwise).
  const chargedUnit = (i: CartItem) => (isBalotra ? unitBase(i) : finalUnitPrice(i));
  const subtotal = cartTotal(cart) - shipWaiver;

  // Auto-apply a creator referral code (captured from a ?ref= link) so the order
  // is credited to the creator who shared it. Runs once after the cart is ready,
  // and only if the customer hasn't already applied a coupon themselves.
  const refTried = useRef(false);
  useEffect(() => {
    if (refTried.current || couponApplied || subtotal <= 0) return;
    let stored: { code?: string; ts?: number } = {};
    try { stored = JSON.parse(localStorage.getItem('mfh_ref') ?? '{}'); } catch {}
    if (!stored.code) return;
    // Referral expires after 30 days
    if (stored.ts && Date.now() - stored.ts > 30 * 24 * 60 * 60 * 1000) return;
    refTried.current = true;
    (async () => {
      try {
        const res = await couponsApi.validate(stored.code!, subtotal, customer?.id);
        setCouponApplied({ code: res.code, discount: res.discount, message: res.message });
      } catch { /* code not valid for this order — ignore */ }
    })();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [subtotal, couponApplied]);

  // COD availability for the entered pincode. The backend switches COD off for pincodes the
  // store has blocked (fraud/returns control) and for areas the courier doesn't do COD in.
  // If COD isn't available we hide the option and fall back to online payment.
  useEffect(() => {
    const pin = (shipping.pincode || '').replace(/\D/g, '');
    if (pin.length !== 6) { setCodAvailable(true); return; }
    let cancelled = false;
    (async () => {
      try {
        const r = await ordersApi.checkPincode(pin);
        if (cancelled) return;
        const ok = r.cod !== false;
        setCodAvailable(ok);
        if (!ok) setPayMethod('online');
      } catch { if (!cancelled) setCodAvailable(true); }
    })();
    return () => { cancelled = true; };
  }, [shipping.pincode]);

  const discount = couponApplied?.discount ?? 0;
  const shippingCost = 0;   // shipping is folded into item prices (or waived for Balotra); no separate charge
  // Cash on Delivery adds a flat ₹50 handling fee; online payment has none.
  const codFee = payMethod === 'cod' ? codFeeAmt : 0;
  const total = Math.max(0, subtotal - discount) + codFee;

  // Loyalty wallet: how much of this order can be paid from the wallet. Capped at the balance
  // and at loyaltyRedeemMaxPercent of the order (same cap the server enforces). The remaining
  // amount (amountToPay) is what the gateway charges / COD collects.
  const walletShown = walletEnabled && !!customer && walletBalance > 0;
  const walletCap = Math.floor(Math.min(walletBalance, total * walletRedeemPct / 100, total) * 100) / 100;
  const walletApplied = walletShown && useWallet ? walletCap : 0;
  const amountToPay = Math.max(0, +(total - walletApplied).toFixed(2));
  // Cash on Delivery advance: paid online now, the courier collects the rest.
  const codAdvanceDue = payMethod === 'cod' ? Math.min(codAdvanceAmt, amountToPay) : 0;
  const codDueOnDelivery = Math.max(0, +(amountToPay - codAdvanceDue).toFixed(2));
  const requiresPan = false;   // PAN no longer mandatory at checkout (disabled on request)

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) return;
    setCouponError(''); setCouponLoading(true);
    try {
      const res = await couponsApi.validate(couponCode, subtotal, customer?.id);
      setCouponApplied({ code: res.code, discount: res.discount, message: res.message });
      setCouponError('');
    } catch (e) {
      setCouponApplied(null);
      setCouponError((e as Error).message || 'Invalid coupon code.');
    } finally { setCouponLoading(false); }
  };

  const removeCoupon = () => {
    setCouponApplied(null); setCouponCode(''); setCouponError('');
  };

  // The coupon code the order is attributed to: a coupon the customer applied,
  // or — failing that — the creator referral code captured from a ?ref= link.
  // This credits the creator even when the coupon discount itself didn't apply.
  const attributionCode = (): string | undefined => {
    if (couponApplied?.code) return couponApplied.code;
    try {
      const s = storage.json<any>('mfh_ref', {});
      if (s.code && (!s.ts || Date.now() - s.ts <= 30 * 24 * 60 * 60 * 1000)) return s.code;
    } catch { /* ignore */ }
    return undefined;
  };

  // Change a quantity without leaving checkout. Dropping to zero removes the
  // line, and an empty cart sends them back rather than leaving a dead page.
  const changeQty = (item: CartItem, next: number) => {
    if (next < 1) removeFromCart(item.dbId, item.selectedSize, item.selectedColor);
    else updateQuantity(item.dbId, next, item.selectedSize, item.selectedColor);
    const fresh = getCart();
    setCart(fresh);
    window.dispatchEvent(new Event('cart-updated'));
    if (fresh.length === 0) router.push('/cart');
  };

  const buildCartLines = () => cart.map(i => {
    // Look up the selected colour's code / photo / column from the product's extraJson
    let colorCode = '', colorPhoto = '', colorColumn = '';
    if (i.selectedColor) {
      try {
        const ex = JSON.parse(i.extraJson ?? '{}');
        const cc = (ex.customColors ?? []).find((c: { name?: string }) => c.name === i.selectedColor);
        if (cc) { colorCode = cc.code ?? ''; colorPhoto = cc.photo ?? ''; colorColumn = cc.columnLetter ?? ''; }
        if (!colorCode) colorCode = (ex.colorCodes ?? {})[i.selectedColor] ?? '';
      } catch { /* extraJson missing or malformed — leave colour meta blank */ }
    }
    return {
      id: String(i.dbId),
      name: i.name,
      sku: i.sku ?? '',
      size: [i.selectedSize, i.selectedColor].filter(Boolean).join(' / '),
      image: i.image ?? '',
      quantity: i.quantity,
      price: chargedUnit(i),
      lineTotal: chargedUnit(i) * i.quantity,
      category: i.category,
      subcategory: i.subcategory,
      gstRate: i.gstRate ?? 5,
      hsn: i.hsnCode ?? '6211',
      // Structured colour info for admin order display
      color: i.selectedColor ?? '',
      colorCode,
      colorPhoto,
      colorColumn,
    };
  });

  const handlePincodeChange = (val: string) => {
    const state = val.length >= 2 ? getPincodeState(val) : '';
    setShipping(s => ({ ...s, pincode: val, ...(state ? { state } : {}) }));
  };

  const validateShipping = () => {
    if (!shipping.name || !shipping.phone || !shipping.address || !shipping.city || !shipping.pincode || !shipping.state) {
      alert('Please fill all shipping fields.');
      return false;
    }
    if (!/^[6-9]\d{9}$/.test((shipping.phone || '').replace(/\D/g, '').slice(-10))) {
      alert('Please enter a valid 10-digit mobile number.');
      return false;
    }
    if (!/^\d{6}$/.test(shipping.pincode || '')) {
      alert('Pincode must be 6 digits.');
      return false;
    }
    if ((shipping as any).email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test((shipping as any).email)) {
      alert('Please enter a valid email address.');
      return false;
    }
    if (requiresPan) {
      if (!panData.panNumber || !panData.panName) {
        alert('PAN card details are required for orders above ₹2000.');
        return false;
      }
      const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
      if (!panRegex.test(panData.panNumber.toUpperCase())) {
        alert('Please enter a valid PAN number (e.g. ABCDE1234F).');
        return false;
      }
    }
    return true;
  };

  // ── Cashfree (PRIMARY online gateway) ──────────────────────────────────────
  const handleCashfree = async (): Promise<boolean> => {
    const cartLines = buildCartLines();
    let res;
    try {
      res = await cashfreeApi.createOrder({
        amount: amountToPay,
        currency: 'INR',
        cart: cartLines,
        customer,
        shipping,
        customerId: customer?.id?.toString(),
        customerName: shipping.name,
        customerEmail: shipping.email || customer?.email || '',
        customerPhone: shipping.phone,
        walletUsed: walletApplied,
        fullTotal: total,
      });
    } catch (e) {
      // Cashfree not configured yet → signal caller to fall back to Razorpay.
      if ((e as Error).message?.toLowerCase().includes('not configured')) return false;
      throw e;
    }

    await ensureCashfreeSdk();
    // @ts-expect-error Cashfree SDK loaded via script tag
    const cashfree = window.Cashfree({ mode: res.mode === 'sandbox' ? 'sandbox' : 'production' });
    // Full-page redirect to Cashfree's hosted checkout. On success the page navigates
    // away and, after payment, Cashfree returns to /checkout?cf_order=<id> (via the
    // backend return_url) where the mount effect verifies and shows the success screen.
    // IMPORTANT: do NOT run verify()/alert() here — with '_self' the promise can resolve
    // while navigation is still pending, and a synchronous alert() would BLOCK that
    // redirect (leaving the user stuck on \"Payment not confirmed\"). Only surface a
    // genuine SDK error; otherwise let the redirect proceed.
    const result = await cashfree.checkout({
      paymentSessionId: res.paymentSessionId,
      redirectTarget: '_self',
    });
    if (result?.error) {
      alert('Payment could not be started: ' + (result.error?.message || 'Please try again.'));
    }
    setLoading(false);
    return true;
  };

  // Pay Online: Cashfree first; falls back to Razorpay only if Cashfree keys
  // are not configured (or admin has set paymentGateway=razorpay in Settings).
  const handlePayOnline = async () => {
    if (cart.length === 0) { alert('Your cart is empty. Please add items before placing an order.'); router.push('/cart'); return; }
    if (!validateShipping()) return;
    setLoading(true);
    try {
      let gateway = 'cashfree';
      try {
        const s = await settingsApi.getAll();
        if ((s.settings?.paymentGateway || '').toLowerCase() === 'razorpay') gateway = 'razorpay';
      } catch { /* settings unavailable — keep cashfree-first */ }

      if (gateway === 'cashfree') {
        const handled = await handleCashfree();
        if (handled) return;
      }
      await startRazorpay();
    } catch (e) {
      alert('Payment init failed: ' + (e as Error).message);
      setLoading(false);
    }
  };

  // Cash on Delivery: no gateway. Place the order directly with method 'cod'.
  // The ₹50 COD fee is also enforced server-side, so it can't be bypassed.
  const handlePlaceCod = () => {
    // Never place an order with an empty cart — otherwise a stray click (e.g. after the
    // cart was cleared or a double-submit) would create a ₹0-goods / ₹50-COD ghost order.
    if (cart.length === 0) { alert('Your cart is empty. Please add items before placing an order.'); router.push('/cart'); return; }
    if (!validateShipping()) return;
    // Flipkart-style confirmation step: show a "Confirm Cash on Delivery Order" popup and
    // only place the order once the customer taps Confirm.
    setCodConfirm(true);
  };

  // The COD order payload, built once so it can also be replayed after the advance
  // payment sends the shopper away to Cashfree and back.
  const buildCodPayload = (localOrderId: string) => {
    const cartLines = buildCartLines();
    return {
      id: localOrderId,
      method: 'cod',
        status: 'Pending',
        paymentId: '',
        cart: cartLines,
        subtotal,
        shippingCost,
      codFee,
        total,
        walletUsed: walletApplied,
        customerId: customer?.id?.toString(),
        customerName: shipping.name,
        customerEmail: shipping.email,
        customerPhone: shipping.phone,
        panNumber: requiresPan ? panData.panNumber : undefined,
        panName: requiresPan ? panData.panName : undefined,
        couponCode: attributionCode(),
        discountAmount: couponApplied?.discount ?? 0,
        shippingName: shipping.name,
        shippingAddress: shipping.address,
        shippingCity: shipping.city,
        shippingPincode: shipping.pincode,
        shippingState: shipping.state,
      placedAt: new Date().toISOString(),
      gaClientId: getGaClientId(),
    };
  };

  const finishCod = (localOrderId: string) => {
    trackEvent('purchase', {
      transaction_id: localOrderId,
      currency: 'INR',
      value: total,
      coupon: attributionCode() || undefined,
      items: cartToItems(cart),
    });
    trackAdsConversion({ value: total, currency: 'INR', transactionId: localOrderId });
    clearCart();
    setOrderId(localOrderId);
    setStep('confirm');
    setLoading(false);
  };

  // Actually place the COD order — runs after the customer confirms in the popup.
  const doPlaceCod = async () => {
    setCodConfirm(false);
    setLoading(true);
    try {
      // With an advance switched on, the shopper pays that part online first. The order is
      // only placed once the payment comes back verified, so an abandoned payment leaves no
      // order behind — which is the whole point of taking an advance.
      if (codAdvanceDue > 0) {
        const cf = await cashfreeApi.createOrder({
          amount: codAdvanceDue,
          currency: 'INR',
          cart: buildCartLines(),
          customer,
          shipping,
          customerId: customer?.id?.toString(),
          customerName: shipping.name,
          customerEmail: shipping.email || customer?.email || '',
          customerPhone: shipping.phone,
          walletUsed: walletApplied,
          fullTotal: total,
        });
        // Cashfree hands us the order number; the order will be placed under the same one.
        try {
          sessionStorage.setItem('mfh-pending-cod', JSON.stringify({
            id: cf.localOrderId,
            payload: buildCodPayload(cf.localOrderId),
          }));
        } catch { /* private mode — the webhook still records the payment */ }

        await ensureCashfreeSdk();
        // @ts-expect-error Cashfree SDK loaded via script tag
        const cashfree = window.Cashfree({ mode: cf.mode === 'sandbox' ? 'sandbox' : 'production' });
        const result = await cashfree.checkout({ paymentSessionId: cf.paymentSessionId, redirectTarget: '_self' });
        if (result?.error) {
          alert('Payment could not be started: ' + (result.error?.message || 'Please try again.'));
          setLoading(false);
        }
        return;
      }

      // Unique order number: timestamp + 4 random digits — two orders in the same
      // millisecond can never collide (prevents duplicate order numbers site-wide).
      const localOrderId = 'MFH' + Date.now() + Math.floor(1000 + Math.random() * 9000);
      await ordersApi.place(buildCodPayload(localOrderId) as any, getToken() ?? undefined);
      finishCod(localOrderId);
    } catch (e) {
      alert('Order failed: ' + (e as Error).message);
      setLoading(false);
    }
  };

  const startRazorpay = async () => {
    try {
      const cartLines = buildCartLines();
      const res = await paymentsApi.createOrder({
        amount: amountToPay,
        currency: 'INR',
        cart: cartLines,
        customer,
        shipping,
      });

      const options = {
        key: res.keyId,
        amount: res.amountPaise,
        currency: 'INR',
        order_id: res.orderId,
        name: 'Mahalaxmi Fashion Hub',
        prefill: {
          name: shipping.name,
          contact: shipping.phone,
          email: shipping.email || customer?.email || '',
        },
        handler: async (response: { razorpay_payment_id: string; razorpay_order_id: string; razorpay_signature: string }) => {
          // The success screen (with the order number) must ONLY appear once the payment is
          // verified AND the order is actually saved. If either step fails, we show a clear
          // support message instead — never a fake "Order Placed".
          try {
            await paymentsApi.verify({
              razorpayOrderId: response.razorpay_order_id,
              razorpayPaymentId: response.razorpay_payment_id,
              razorpaySignature: response.razorpay_signature,
            });
            await ordersApi.place({
              id: res.localOrderId,
              method: 'razorpay',
              status: 'Pending',
              paymentId: response.razorpay_payment_id,
              cart: cartLines,
              subtotal,
              shippingCost,
              codFee: 0,
              total,
              walletUsed: walletApplied,
              customerId: customer?.id?.toString(),
              customerName: shipping.name,
              customerEmail: shipping.email,
              customerPhone: shipping.phone,
              panNumber: requiresPan ? panData.panNumber : undefined,
              panName: requiresPan ? panData.panName : undefined,
              couponCode: attributionCode(),
              discountAmount: couponApplied?.discount ?? 0,
              shippingName: shipping.name,
              shippingAddress: shipping.address,
              shippingCity: shipping.city,
              shippingPincode: shipping.pincode,
              shippingState: shipping.state,
              placedAt: new Date().toISOString(),
              gaClientId: getGaClientId(),
            }, getToken() ?? undefined);
            // GA4: successful purchase (fired before clearing the cart so items are still available).
            trackEvent('purchase', {
              transaction_id: res.localOrderId,
              currency: 'INR',
              value: total,
              coupon: attributionCode() || undefined,
              items: cartToItems(cart),
            });
            trackAdsConversion({ value: total, currency: 'INR', transactionId: res.localOrderId });
            clearCart();
            setOrderId(res.localOrderId);
            setStep('confirm');
          } catch {
            alert('Your payment was received, but we could not confirm your order automatically. Please do NOT pay again — contact us on WhatsApp (payment reference: ' + res.localOrderId + ') and we will confirm your order for you.');
          } finally {
            setLoading(false);
          }
        },
        modal: { ondismiss: () => setLoading(false) },
      };
      // @ts-expect-error Razorpay loaded via script tag
      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch (e) {
      alert('Payment init failed: ' + (e as Error).message);
      setLoading(false);
    }
  };

  if (step === 'confirm') return (
    <div style={{ maxWidth: '520px', margin: '0 auto', padding: '4rem 1.5rem', textAlign: 'center' }}>
      <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>✅</div>
      <h1 style={{ fontSize: '1.75rem', fontWeight: 700, color: '#27ae60', marginBottom: '.5rem' }}>Order Placed!</h1>
      <p style={{ color: '#555', marginBottom: '.25rem' }}>Order ID: <strong>{orderId}</strong></p>
      <p style={{ color: '#666', fontSize: '.92rem', marginBottom: '1.5rem' }}>
        Thank you for your order! We&apos;ll keep you updated as it&apos;s processed.
      </p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '.85rem', alignItems: 'center' }}>
        <button onClick={() => router.push('/')} className="button primary">Continue Shopping</button>
      </div>
    </div>
  );

  return (
    <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '2.5rem 1.5rem' }}>
      <script src="https://sdk.cashfree.com/js/v3/cashfree.js" async />
      <script src="https://checkout.razorpay.com/v1/checkout.js" async />
      <style dangerouslySetInnerHTML={{ __html: `
        /* Grid items default to min-width:auto, which refuses to shrink below their
           content and pushes the layout off-screen (the bug seen in the mobile app).
           min-width:0 lets tracks actually shrink so nothing overflows to the right. */
        .checkout-outer-grid, .checkout-shipping-grid, .checkout-pan-grid { min-width: 0; }
        .checkout-outer-grid > *, .checkout-shipping-grid > *, .checkout-pan-grid > * { min-width: 0; }
        @media (max-width: 700px) {
          .checkout-outer-grid { grid-template-columns: minmax(0, 1fr) !important; }
          .checkout-shipping-grid { grid-template-columns: minmax(0, 1fr) !important; }
          .checkout-pan-grid { grid-template-columns: minmax(0, 1fr) !important; }
          .checkout-summary { position: static !important; }
        }
      ` }} />
      <h1 style={{ fontSize: '1.75rem', fontWeight: 700, marginBottom: '1.5rem', color: '#722f37' }}>Checkout</h1>

      <div className="checkout-outer-grid" style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) 320px', gap: '2rem', alignItems: 'start' }}>
        {/* Left: Shipping + Payment */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
          {!customer && (
            <div className="card" style={{ padding: '1rem 1.25rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '1rem', flexWrap: 'wrap', border: '1.5px solid #f3d5dc', background: '#fff8f9' }}>
              <div>
                <strong style={{ color: '#722f37' }}>Login to auto-fill shipping details</strong>
                <p style={{ margin: '.2rem 0 0', fontSize: '.85rem', color: '#666' }}>After login, your saved name, phone, email and address will fill automatically.</p>
              </div>
              <button type="button" onClick={() => router.push('/account?return=/checkout')} className="button primary" style={{ whiteSpace: 'nowrap' }}>
                Login
              </button>
            </div>
          )}

          {/* Shipping Form */}
          <div className="card" style={{ padding: '1.5rem' }}>
            {/* Honeypot — hidden from users, bots fill it */}
            <input type="text" name="website" value={honeypot} onChange={e => setHoneypot(e.target.value)}
              style={{ display: 'none' }} tabIndex={-1} autoComplete="off" aria-hidden="true" />
            {savedAddresses.length > 0 && (
              <div className="ck-addr-book">
                <div className="ck-addr-head">
                  <div>
                    <h2>Saved Addresses</h2>
                    <p>Select your delivery address.</p>
                  </div>
                  <Link href="/account/address" className="ck-addr-manage">+ Manage Addresses</Link>
                </div>
                <div className="ck-addr-grid">
                  {savedAddresses.map(a => (
                    <button key={a.id} type="button" onClick={() => applyAddress(a)}
                      className={`ck-addr-card${pickedAddressId === a.id ? ' picked' : ''}`}>
                      <span className="ck-addr-label">
                        <svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true">
                          <path fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" d="M12 21.5s7-5.6 7-11a7 7 0 1 0-14 0c0 5.4 7 11 7 11Z" />
                          <circle cx="12" cy="10.2" r="2.4" fill="none" stroke="currentColor" strokeWidth="1.9" />
                        </svg>
                        {a.label.toUpperCase()}
                        {a.isDefault && <em>DEFAULT</em>}
                      </span>
                      <strong>{a.fullName}</strong>
                      <span className="ck-addr-phone">+91 {a.phone}</span>
                      <span className="ck-addr-lines">
                        {[a.addrLine1, a.addrLine2].filter(Boolean).join(', ')}
                        <br />{[a.city, a.state].filter(Boolean).join(', ')}{a.pincode ? ` - ${a.pincode}` : ''}
                      </span>
                      {pickedAddressId === a.id && <span className="ck-addr-tick" aria-hidden="true">✓</span>}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <h2 style={{ fontWeight: 700, fontSize: '1.1rem', marginBottom: '1.25rem' }}>Shipping Details</h2>
            <div className="checkout-shipping-grid" style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) minmax(0, 1fr)', gap: '1rem' }}>
              {/* Full Name */}
              <div>
                <label style={{ fontSize: '.85rem', fontWeight: 600, display: 'block', marginBottom: '.3rem' }}>Full Name *</label>
                <input value={shipping.name} onChange={e => setShipping(s => ({ ...s, name: e.target.value }))}
                  style={{ width: '100%', border: '1.5px solid #ddd', borderRadius: '8px', padding: '.6rem .75rem', fontSize: '.9rem', boxSizing: 'border-box' }} />
              </div>
              {/* Email */}
              <div>
                <label style={{ fontSize: '.85rem', fontWeight: 600, display: 'block', marginBottom: '.3rem' }}>Email</label>
                <input type="email" value={shipping.email} onChange={e => setShipping(s => ({ ...s, email: e.target.value }))}
                  style={{ width: '100%', border: '1.5px solid #ddd', borderRadius: '8px', padding: '.6rem .75rem', fontSize: '.9rem', boxSizing: 'border-box' }} />
              </div>
              {/* Phone */}
              <div>
                <label style={{ fontSize: '.85rem', fontWeight: 600, display: 'block', marginBottom: '.3rem' }}>Phone *</label>
                <input value={shipping.phone} onChange={e => setShipping(s => ({ ...s, phone: e.target.value }))}
                  style={{ width: '100%', border: '1.5px solid #ddd', borderRadius: '8px', padding: '.6rem .75rem', fontSize: '.9rem', boxSizing: 'border-box' }} />
              </div>
              {/* Pincode */}
              <div>
                <label style={{ fontSize: '.85rem', fontWeight: 600, display: 'block', marginBottom: '.3rem' }}>Pincode *</label>
                <input value={shipping.pincode} maxLength={6} onChange={e => handlePincodeChange(e.target.value)}
                  style={{ width: '100%', border: '1.5px solid #ddd', borderRadius: '8px', padding: '.6rem .75rem', fontSize: '.9rem', boxSizing: 'border-box' }} />
              </div>
              {/* Address */}
              <div style={{ gridColumn: '1 / -1' }}>
                <label style={{ fontSize: '.85rem', fontWeight: 600, display: 'block', marginBottom: '.3rem' }}>Address *</label>
                <input value={shipping.address} onChange={e => setShipping(s => ({ ...s, address: e.target.value }))}
                  style={{ width: '100%', border: '1.5px solid #ddd', borderRadius: '8px', padding: '.6rem .75rem', fontSize: '.9rem', boxSizing: 'border-box' }} />
              </div>
              {/* City */}
              <div>
                <label style={{ fontSize: '.85rem', fontWeight: 600, display: 'block', marginBottom: '.3rem' }}>City / District *</label>
                <input value={shipping.city} onChange={e => setShipping(s => ({ ...s, city: e.target.value }))}
                  style={{ width: '100%', border: '1.5px solid #ddd', borderRadius: '8px', padding: '.6rem .75rem', fontSize: '.9rem', boxSizing: 'border-box' }} />
              </div>
              {/* State */}
              <div>
                <label style={{ fontSize: '.85rem', fontWeight: 600, display: 'block', marginBottom: '.3rem' }}>State *</label>
                <input value={shipping.state} onChange={e => setShipping(s => ({ ...s, state: e.target.value }))}
                  style={{ width: '100%', border: '1.5px solid #ddd', borderRadius: '8px', padding: '.6rem .75rem', fontSize: '.9rem', boxSizing: 'border-box' }} />
              </div>
            </div>
          </div>

          {/* Delivery-time pincode check (below delivery address) */}
          <PincodeChecker />

          {/* PAN section (if required) */}
          {requiresPan && (
            <div className="card" style={{ padding: '1.5rem', border: '1.5px solid #f5c6cb', background: '#fff8f9' }}>
              <h2 style={{ fontWeight: 700, fontSize: '1.1rem', marginBottom: '.5rem', color: '#722f37' }}>PAN Card Details Required</h2>
              <p style={{ fontSize: '.85rem', color: '#666', marginBottom: '1rem' }}>
                As per government regulations, PAN details are mandatory for orders above ₹2,000.
              </p>
              <div className="checkout-pan-grid" style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) minmax(0, 1fr)', gap: '1rem' }}>
                <div>
                  <label style={{ fontSize: '.85rem', fontWeight: 600, display: 'block', marginBottom: '.3rem' }}>PAN Number *</label>
                  <input value={panData.panNumber} onChange={e => setPanData(p => ({ ...p, panNumber: e.target.value.toUpperCase() }))}
                    placeholder="ABCDE1234F" maxLength={10}
                    style={{ width: '100%', border: '1.5px solid #ddd', borderRadius: '8px', padding: '.6rem .75rem', fontSize: '.9rem', boxSizing: 'border-box', textTransform: 'uppercase' }} />
                </div>
                <div>
                  <label style={{ fontSize: '.85rem', fontWeight: 600, display: 'block', marginBottom: '.3rem' }}>Name as on PAN *</label>
                  <input value={panData.panName} onChange={e => setPanData(p => ({ ...p, panName: e.target.value }))}
                    placeholder="Full Name"
                    style={{ width: '100%', border: '1.5px solid #ddd', borderRadius: '8px', padding: '.6rem .75rem', fontSize: '.9rem', boxSizing: 'border-box' }} />
                </div>
              </div>
            </div>
          )}

          {/* Payment */}
          <div className="card" style={{ padding: '1.5rem' }}>
            <h2 style={{ fontWeight: 700, fontSize: '1.1rem', marginBottom: '1rem' }}>Payment Method</h2>

            {/* Choose Pay Online vs Cash on Delivery */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '.6rem', marginBottom: '1rem' }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: '.6rem', border: `1.5px solid ${payMethod === 'online' ? '#722f37' : '#ddd'}`, background: payMethod === 'online' ? '#fff8f9' : '#fff', borderRadius: '10px', padding: '.75rem .9rem', cursor: 'pointer' }}>
                <input type="radio" name="payMethod" checked={payMethod === 'online'} onChange={() => setPayMethod('online')} style={{ accentColor: '#722f37' }} />
                <span style={{ fontWeight: 600, fontSize: '.92rem' }}>💳 Pay Online</span>
                <span style={{ fontSize: '.8rem', color: '#666' }}>UPI / Card / Net Banking</span>
              </label>
              {codAvailable ? (
                <label style={{ display: 'flex', alignItems: 'center', gap: '.6rem', border: `1.5px solid ${payMethod === 'cod' ? '#722f37' : '#ddd'}`, background: payMethod === 'cod' ? '#fff8f9' : '#fff', borderRadius: '10px', padding: '.75rem .9rem', cursor: 'pointer' }}>
                  <input type="radio" name="payMethod" checked={payMethod === 'cod'} onChange={() => setPayMethod('cod')} style={{ accentColor: '#722f37' }} />
                  <span style={{ fontWeight: 600, fontSize: '.92rem' }}>🚚 Cash on Delivery</span>
                  {codAdvanceAmt > 0
                    ? <span style={{ fontSize: '.8rem', color: '#c0392b', fontWeight: 600 }}>₹{codAdvanceAmt} advance online</span>
                    : codFeeAmt > 0
                      ? <span style={{ fontSize: '.8rem', color: '#c0392b', fontWeight: 600 }}>+₹{codFeeAmt} extra</span>
                      : null}
                </label>
              ) : (
                <div style={{ display: 'flex', alignItems: 'center', gap: '.6rem', border: '1.5px solid #eee', background: '#fafafa', borderRadius: '10px', padding: '.75rem .9rem', opacity: .7 }}>
                  <span style={{ fontWeight: 600, fontSize: '.92rem', color: '#999' }}>🚚 Cash on Delivery</span>
                  <span style={{ fontSize: '.78rem', color: '#c0392b' }}>Not available for this pincode — please pay online</span>
                </div>
              )}
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '.75rem' }}>
              {payMethod === 'online' ? (
                <button onClick={handlePayOnline} disabled={loading} className="button primary" style={{ width: '100%' }}>
                  {loading ? 'Processing…' : `💳 Pay Online — ₹${amountToPay.toLocaleString('en-IN')}`}
                </button>
              ) : (
                <button onClick={handlePlaceCod} disabled={loading} className="button primary" style={{ width: '100%' }}>
                  {loading
                    ? 'Placing order…'
                    : codAdvanceDue > 0
                      ? `💳 Pay ₹${codAdvanceDue.toLocaleString('en-IN')} Advance & Place Order`
                      : `🚚 Place COD Order — ₹${amountToPay.toLocaleString('en-IN')}`}
                </button>
              )}
              {payMethod === 'cod' && (
                <p style={{ fontSize: '.8rem', color: '#666', margin: 0, textAlign: 'center' }}>
                  {codAdvanceDue > 0
                    ? `Pay ₹${codAdvanceDue.toLocaleString('en-IN')} online now to confirm your order. The remaining ₹${codDueOnDelivery.toLocaleString('en-IN')} is paid in cash when it arrives.`
                    : codFeeAmt > 0
                      ? `A ₹${codFeeAmt} handling fee is added for Cash on Delivery. Pay the total in cash when your order arrives.`
                      : 'Pay in cash when your order arrives.'}
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Order Summary */}
        <div className="card checkout-summary" style={{ padding: '1.25rem', position: 'sticky', top: '1rem' }}>
          <h2 style={{ fontWeight: 700, marginBottom: '1rem' }}>Order Summary</h2>
          <div style={{ maxHeight: '340px', overflowY: 'auto', marginBottom: '1rem' }}>
            {cart.map(i => {
              const variant = [i.selectedSize, i.selectedColor].filter(Boolean).join(' · ');
              const img = productImageSrc(i.image);
              return (
                <div className="ck-line" key={`${i.dbId}-${i.selectedSize}-${i.selectedColor}`}>
                  {/* Photo, with the quantity right underneath it */}
                  <div className="ck-line-media">
                    {img
                      ? <img className="ck-line-img" src={img} alt="" loading="lazy" />
                      : <div className="ck-line-img ck-line-img-ph" aria-hidden="true">👗</div>}
                    <div className="ck-line-qty">
                      <button type="button" onClick={() => changeQty(i, i.quantity - 1)}
                        aria-label={`Reduce quantity of ${i.name}`}>−</button>
                      <span>{i.quantity}</span>
                      <button type="button"
                        disabled={i.maxStock !== undefined && i.quantity >= i.maxStock}
                        onClick={() => changeQty(i, i.quantity + 1)}
                        aria-label={`Increase quantity of ${i.name}`}>+</button>
                    </div>
                  </div>

                  <div className="ck-line-body">
                    <p className="ck-line-name">{i.name}</p>
                    {variant && <p className="ck-line-variant">{variant}</p>}
                    <p className="ck-line-price">₹{(chargedUnit(i) * i.quantity).toLocaleString('en-IN')}</p>
                    {i.maxStock !== undefined && i.quantity >= i.maxStock && (
                      <p className="ck-line-cap">Only {i.maxStock} in stock</p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
          {/* Coupon Input */}
          <div style={{ borderTop: '1px solid #eee', paddingTop: '.75rem', marginBottom: '.5rem' }}>
            {couponApplied ? (
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#f0fdf4', border: '1px solid #c8e6c9', borderRadius: '8px', padding: '.5rem .75rem', fontSize: '.85rem' }}>
                <span style={{ color: '#166534', fontWeight: 600 }}>🎟️ {couponApplied.code} — ₹{couponApplied.discount.toLocaleString('en-IN')} off</span>
                <button onClick={removeCoupon} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#888', fontSize: '1rem' }} aria-label="Remove coupon">✕</button>
              </div>
            ) : (
              <div style={{ display: 'flex', gap: '.5rem' }}>
                <input
                  value={couponCode} onChange={e => { setCouponCode(e.target.value.toUpperCase()); setCouponError(''); }}
                  placeholder="Coupon code"
                  style={{ flex: 1, border: '1.5px solid #ddd', borderRadius: '8px', padding: '.5rem .75rem', fontSize: '.88rem', outline: 'none' }}
                  onKeyDown={e => e.key === 'Enter' && handleApplyCoupon()}
                />
                <button onClick={handleApplyCoupon} disabled={couponLoading || !couponCode.trim()}
                  style={{ background: '#722f37', color: '#fff', border: 'none', borderRadius: '8px', padding: '0 1rem', fontWeight: 700, fontSize: '.88rem', cursor: 'pointer', whiteSpace: 'nowrap', opacity: couponLoading ? .7 : 1 }}>
                  {couponLoading ? '...' : 'Apply'}
                </button>
              </div>
            )}
            {couponError && <p style={{ color: '#c0392b', fontSize: '.82rem', marginTop: '.3rem' }}>{couponError}</p>}
          </div>

          {/* Loyalty wallet */}
          {walletShown && (
            <div style={{ borderTop: '1px solid #eee', paddingTop: '.75rem', marginBottom: '.25rem' }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: '.6rem', cursor: 'pointer' }}>
                <input type="checkbox" checked={useWallet} onChange={e => setUseWallet(e.target.checked)} style={{ accentColor: '#722f37' }} />
                <span style={{ fontSize: '.88rem', fontWeight: 600, color: '#1a1a1a' }}>👛 Use wallet balance</span>
                <span style={{ marginLeft: 'auto', fontSize: '.82rem', color: '#666' }}>₹{walletBalance.toLocaleString('en-IN')} available</span>
              </label>
              {useWallet && (walletApplied > 0
                ? <p style={{ fontSize: '.78rem', color: '#27ae60', margin: '.35rem 0 0' }}>−₹{walletApplied.toLocaleString('en-IN')} applied (max {walletRedeemPct}% of this order)</p>
                : <p style={{ fontSize: '.78rem', color: '#999', margin: '.35rem 0 0' }}>Wallet cannot be applied to this order.</p>)}
            </div>
          )}

          <div style={{ borderTop: '1px solid #eee', paddingTop: '.75rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.9rem', marginBottom: '.4rem' }}>
              <span>Subtotal</span><span>₹{subtotal.toLocaleString('en-IN')}</span>
            </div>
            {discount > 0 && (
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.9rem', marginBottom: '.4rem', color: '#27ae60' }}>
                <span>Discount ({couponApplied?.code})</span><span>−₹{discount.toLocaleString('en-IN')}</span>
              </div>
            )}
            {isBalotra && shipWaiver > 0 && (
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.9rem', marginBottom: '.4rem', color: '#27ae60' }}>
                <span>Local delivery (Balotra)</span><span>FREE</span>
              </div>
            )}
            {codFee > 0 && (
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.9rem', marginBottom: '.4rem' }}>
                <span>COD charge</span><span>+₹{codFee.toLocaleString('en-IN')}</span>
              </div>
            )}
            <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700, fontSize: '1.1rem', paddingTop: '.5rem', borderTop: '1px solid #eee' }}>
              <span>Total</span>
              <span style={{ color: '#722f37' }}>₹{total.toLocaleString('en-IN')}</span>
            </div>
            {walletApplied > 0 && (
              <>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.9rem', marginTop: '.4rem', color: '#27ae60' }}>
                  <span>👛 Paid from wallet</span><span>−₹{walletApplied.toLocaleString('en-IN')}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 800, fontSize: '1.1rem', marginTop: '.3rem' }}>
                  <span>To Pay</span><span style={{ color: '#722f37' }}>₹{amountToPay.toLocaleString('en-IN')}</span>
                </div>
              </>
            )}
            {codAdvanceDue > 0 && (
              <div style={{ marginTop: '.7rem', paddingTop: '.7rem', borderTop: '1px dashed #e6d9dd' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.92rem', fontWeight: 800 }}>
                  <span>Pay now (advance)</span>
                  <span style={{ color: '#722f37' }}>₹{codAdvanceDue.toLocaleString('en-IN')}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.92rem', marginTop: '.25rem' }}>
                  <span>Pay on delivery</span>
                  <span>₹{codDueOnDelivery.toLocaleString('en-IN')}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Confirm Cash on Delivery Order — shown before a COD order is placed */}
      {codConfirm && (
        <div
          role="dialog"
          aria-label="Confirm Cash on Delivery Order"
          onClick={() => setCodConfirm(false)}
          style={{ position: 'fixed', inset: 0, zIndex: 3000, background: 'rgba(0,0,0,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem' }}>
          <div
            onClick={e => e.stopPropagation()}
            style={{ background: '#fff', borderRadius: 14, maxWidth: 420, width: '100%', boxShadow: '0 18px 50px rgba(0,0,0,.25)', overflow: 'hidden' }}>
            <div style={{ padding: '1.25rem 1.4rem 0' }}>
              <h3 style={{ margin: 0, fontSize: '1.1rem', fontWeight: 800, color: '#1a1a1a' }}>Confirm Cash on Delivery Order</h3>
              <div style={{ display: 'flex', alignItems: 'center', gap: '.85rem', margin: '.9rem 0 .3rem' }}>
                <div style={{ fontSize: '2rem', lineHeight: 1 }}>🚚</div>
                <p style={{ margin: 0, color: '#722f37', fontWeight: 600, fontSize: '.95rem' }}>
                  Pay via UPI or Cash when you receive your order
                </p>
              </div>
              <div style={{ background: '#fbf3f5', border: '1px solid #f0dfe4', borderRadius: 10, padding: '.7rem .85rem', margin: '.9rem 0 1.1rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.86rem', color: '#555' }}>
                  <span>Order total{codFee > 0 ? ` (incl. ₹${codFee} COD fee)` : ''}</span>
                  <strong style={{ color: '#722f37' }}>₹{total.toLocaleString('en-IN')}</strong>
                </div>
                <p style={{ margin: '.4rem 0 0', fontSize: '.74rem', color: '#999' }}>
                  {codAdvanceDue > 0
                    ? `You will pay ₹${codAdvanceDue.toLocaleString('en-IN')} online now and ₹${codDueOnDelivery.toLocaleString('en-IN')} in cash on delivery.`
                    : `Tip: pay online now to avoid the ₹${codFeeAmt} handling fee.`}
                </p>
              </div>
            </div>
            <div style={{ display: 'flex', gap: '.6rem', padding: '0 1.4rem 1.25rem' }}>
              <button
                onClick={() => setCodConfirm(false)}
                style={{ flex: 1, height: 44, borderRadius: 9, border: '1.5px solid #ddd', background: '#fff', color: '#a01836', fontWeight: 700, fontSize: '.92rem', cursor: 'pointer' }}>
                Cancel
              </button>
              <button
                onClick={doPlaceCod}
                disabled={loading}
                style={{ flex: 1.3, height: 44, borderRadius: 9, border: 'none', background: '#722f37', color: '#fff', fontWeight: 800, fontSize: '.92rem', cursor: loading ? 'default' : 'pointer', opacity: loading ? .7 : 1 }}>
                {loading ? 'Placing…' : 'Confirm order'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
